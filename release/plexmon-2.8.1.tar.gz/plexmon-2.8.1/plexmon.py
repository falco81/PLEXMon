#!/usr/bin/env python3
"""
plexmon — Plex server monitoring daemon (single-file build).

From 2.0 it carries Settings as well: plexmon_admin.py, beside this file, is
otp's engine and administration brought over for a Plex server - accounts,
certificates and TLS, automatic certificates (ACME), upgrades, the console.
The daemon starts it as a thread of its own; the dashboard below is exactly
what it was, open to the LAN without signing in.

A long-running daemon that collects SMART, temperatures, capacity/wear history,
now-playing, activity and performance from a Plex server, and exposes it on a
localhost HTTP API that index.php reads. It never wakes a sleeping disk on a
normal run: power state is inferred from kernel I/O counters, and smartctl is
called only for disks already awake, once a day, or on an explicit request.

This is the merged single-file version of the plexmon package; behaviour is
identical. Run it with:  python3 plexmon.py           (daemon)
                         python3 plexmon.py --check   (self-check)
                         python3 plexmon.py --diag    (API + disk state)
                         python3 plexmon.py --oneshot (one collection, for testing)
"""
from __future__ import annotations

__version__ = "2.8.1"

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse
import grp
import hashlib
import json
import os
import pwd
import re
import secrets
import subprocess
import shutil
import socket
import sys
import tempfile
import threading
import time


# ==========================================================================
# config
# ==========================================================================

# ---- paths ---------------------------------------------------------------
STATE_DIR   = Path("/var/lib/plex-status")     # cache + history live here (root)
WEB_DIR     = Path("/var/www/html/smart")      # what the page reads
RUN_DIR     = Path("/run/plex-status")         # runtime: socket-less API token

DATA_FILE    = WEB_DIR / "data.json"           # the page's main snapshot
SESSIONS_WEB = WEB_DIR / "sessions.json"       # now-playing snapshot fallback
HISTORY_WEB  = WEB_DIR / "history-full.json"   # full-resolution chart data
CACHE_FILE   = STATE_DIR / "smart-cache.json"  # last good SMART per serial
HISTORY_FILE = STATE_DIR / "history.json"      # rolling samples

TOKEN_FILE  = RUN_DIR / "api-token"            # shared secret for the web page

PLEX_PREFS  = Path("/var/lib/plexmediaserver/Library/Application Support/"
                   "Plex Media Server/Preferences.xml")
PLEX_URL    = "http://127.0.0.1:32400"

SMARTCTL = "/usr/sbin/smartctl"
HDPARM   = "/usr/sbin/hdparm"

# ---- API -----------------------------------------------------------------
API_HOST = "127.0.0.1"
API_PORT = 9847               # localhost only; token guards privileged calls

# ---- timing (seconds) ----------------------------------------------------
# The daemon runs a fast loop that only ever touches memory (I/O counters,
# /proc, the Plex API) and a slow cadence for the heavier work. Neither wakes a
# disk: SMART is read only when a disk is demonstrably already awake, or once a
# day, or on an explicit request.
FAST_INTERVAL   = 10          # now-playing, activity, power state, temps-from-io
SLOW_INTERVAL   = 300         # perf probes, history sample, snapshot rebuild
SMART_DAILY_AT  = 4           # hour of day for the one guaranteed SMART sweep

# ---- thresholds ----------------------------------------------------------
TEMP_WARN = 60                # °C — the drives' own alarm point
TEMP_CRIT = 70                # °C — top of the rated operating range
# Flash runs hotter than platters and is rated for it: an NVMe at 60 °C is
# unremarkable, while a hard disk at 60 °C is not. These apply only to NVMe, and
# only when the drive doesn't publish limits of its own — most do, and those
# always win.
TEMP_WARN_NVME = 70
TEMP_CRIT_NVME = 80

# ---- disk behaviour ------------------------------------------------------
# hdparm -C is NOT used: the JMS567 USB bridge mistranslates CHECK POWER MODE
# and both lies about the state and wakes the disk. Power state is inferred from
# kernel I/O counters, which are read from memory.
USE_HDPARM        = False
WAKE_STANDBY      = False      # never read SMART from a sleeping disk on a normal run
SPINDOWN_AFTER_S  = 900        # treat a disk idle this long as spun down
# A disk that is genuinely busy stays "awake" for as long as it's in use, and
# reading SMART is cheap on an awake disk — but not free: every read spawns
# smartctl and puts SCSI traffic on a bus that may be streaming video. Routine
# reads are therefore throttled to this interval; forced passes (wake button,
# daily sweep) ignore it.
SMART_MIN_INTERVAL = 300

# Multi-bay USB-SATA bridges spin up every disk they carry when any one of them
# is touched — the bridge powers the whole group, not individual bays. With this
# on, disks sharing a bridge share a power state: if one has I/O, the others are
# reported as spinning too (because they are), and SMART may be read from them at
# no extra cost since they're already turning. Set false for bridges that really
# do power each bay independently.
BRIDGE_WAKES_SIBLINGS = True

# ---- history -------------------------------------------------------------
HISTORY_DAYS   = 7             # retention by age, not sample count
HISTORY_MAX    = 25000         # hard cap so the file can't grow without bound
HISTORY_POINTS = 140           # down-sampled points embedded in data.json

# ---- Apple TV remote control --------------------------------------------
# Optional. Plex cannot control its own Apple TV app (the client advertises no
# remote-control capability), so this drives Apple's Companion protocol through
# pyatv's CLI, which lives in its own virtualenv and is called like any other
# external tool. Off by default; disk monitoring never depends on it.
ATV_ENABLE  = False          # also covers LG and Samsung
# Empty means "find it": whatever pyatv installed for the interpreter running
# this daemon, then the usual places, then PATH. Set it explicitly to pin one.
ATV_REMOTE  = ""
ATV_STORAGE = "/var/lib/plex-status/atv-creds.json"

# ---- perf probe ----------------------------------------------------------
PERF_ENDPOINTS = ["/identity", "/library/sections", "/hubs"]
PERF_SAMPLES   = 5
# Same endpoints measured through the reverse proxy; the difference against the
# direct figures is nginx's per-request cost (the "Reverse proxy" card). Empty
# string disables the probe. Override via PLEXMON_PERF_PROXY_URL or config.json.
PERF_PROXY_URL = "https://plex.falco81.net"


_CONFIG_NOTES: list = []


def _parse_config(text: str):
    """
    Parse the config file. Accepts strict JSON, and recovers from the easy
    mistake of writing several objects one after another:

        {"spindown_after_s": 600}
        {"bridge_wakes_siblings": true}

    which is not valid JSON. Rather than silently ignoring the whole file — and
    leaving settings that look applied but aren't — the objects are merged and
    the problem is reported.
    """
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
        _CONFIG_NOTES.append("config.json must contain an object; ignored")
        return {}
    except ValueError:
        pass
    merged, dec, idx, n = {}, json.JSONDecoder(), 0, 0
    while idx < len(text):
        while idx < len(text) and text[idx].isspace():
            idx += 1
        if idx >= len(text):
            break
        try:
            obj, end = dec.raw_decode(text, idx)
        except ValueError:
            break
        if isinstance(obj, dict):
            merged.update(obj)
            n += 1
        idx = end
    if n > 1:
        _CONFIG_NOTES.append(
            f"config.json holds {n} separate JSON objects instead of one — "
            "the settings were merged, but please combine them into a single "
            "{...} block")
        return merged
    _CONFIG_NOTES.append("config.json is not valid JSON — DEFAULTS ARE IN USE")
    return {}


# Exactly what may be set from config.json / the environment. An allowlist, not
# "anything spelled in capitals": without it a key like "n" would silently
# overwrite an unrelated internal constant, and a typo would be applied instead
# of reported.
CONFIGURABLE = (
    "API_HOST", "API_PORT",
    "FAST_INTERVAL", "SLOW_INTERVAL", "SMART_DAILY_AT", "SMART_MIN_INTERVAL",
    "SPINDOWN_AFTER_S", "BRIDGE_WAKES_SIBLINGS", "USE_HDPARM", "WAKE_STANDBY",
    "TEMP_WARN", "TEMP_CRIT", "TEMP_WARN_NVME", "TEMP_CRIT_NVME",
    "HISTORY_DAYS", "HISTORY_MAX", "HISTORY_POINTS",
    "PERF_ENDPOINTS", "PERF_SAMPLES", "PERF_PROXY_URL",
    "PLEX_URL", "PLEX_PREFS", "SMARTCTL", "HDPARM",
    "ATV_ENABLE", "ATV_REMOTE", "ATV_STORAGE", "TV_CREDS", "TV_SAMSUNG_KEYS",
    "TV_PAIR_TIMEOUT", "TV_SAMSUNG_KEY_DELAY",
    "STATE_DIR", "WEB_DIR", "RUN_DIR",
    "DATA_FILE", "SESSIONS_WEB", "HISTORY_WEB",
    "CACHE_FILE", "HISTORY_FILE", "TOKEN_FILE",
)


def _apply_overrides(ns: dict) -> None:
    """Layer env vars and the optional JSON config on top of the defaults."""
    cfg_path = Path(os.environ.get("PLEXMON_CONFIG", "/etc/plex-status/config.json"))
    if cfg_path.is_file():
        try:
            data = _parse_config(cfg_path.read_text())
            for k, v in data.items():
                key = k.upper()
                if key in CONFIGURABLE:
                    ns[key] = _coerce(ns[key], v)
                else:
                    _CONFIG_NOTES.append(f"config.json: unknown setting '{k}' ignored")
        except Exception as e:
            _CONFIG_NOTES.append(f"config.json could not be read: {e}")
    for k in CONFIGURABLE:
        env = os.environ.get("PLEXMON_" + k)
        if env is not None:
            ns[k] = _coerce(ns[k], env)

    # Derived paths follow their directory unless set explicitly, so moving
    # state_dir or web_dir actually moves the files instead of leaving them
    # pointing at the defaults.
    given = set()
    try:
        cfgp = Path(os.environ.get("PLEXMON_CONFIG", "/etc/plex-status/config.json"))
        if cfgp.is_file():
            given |= {k.upper() for k in _parse_config(cfgp.read_text())}
    except Exception:
        pass
    given |= {k for k in CONFIGURABLE if os.environ.get("PLEXMON_" + k) is not None}
    for name, base, leaf in (
            ("DATA_FILE", "WEB_DIR", "data.json"),
            ("SESSIONS_WEB", "WEB_DIR", "sessions.json"),
            ("HISTORY_WEB", "WEB_DIR", "history-full.json"),
            ("CACHE_FILE", "STATE_DIR", "smart-cache.json"),
            ("HISTORY_FILE", "STATE_DIR", "history.json"),
            ("TOKEN_FILE", "RUN_DIR", "api-token")):
        if base in given and name not in given:
            ns[name] = ns[base] / leaf


def _coerce(current, value):
    """Make an override match the type of the default it replaces."""
    if isinstance(current, bool):
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ("1", "true", "yes", "on")
    if isinstance(current, int):
        try:
            return int(value)
        except (TypeError, ValueError):
            return current
    if isinstance(current, Path):
        return Path(str(value))
    return value


_apply_overrides(globals())


# ==========================================================================
# util
# ==========================================================================

_DEBUG = False


def set_debug(on: bool) -> None:
    global _DEBUG
    _DEBUG = on


def log(msg: str, *, level: str = "info") -> None:
    """Write to stderr, which journald captures. Debug lines only when asked."""
    if level == "debug" and not _DEBUG:
        return
    ts = time.strftime("%H:%M:%S")
    print(f"[{ts}] {msg}", file=sys.stderr, flush=True)


def run(cmd: list[str], timeout: float = 10.0) -> str:
    """
    Run a command, return stdout, never raise, and never block past the timeout.

    subprocess.run(timeout=...) is not safe here. On timeout it kills the child
    and then *waits* for it — and a smartctl stuck on a wedged USB bridge sits in
    uninterruptible sleep, where SIGKILL does nothing and the wait never returns.
    That hung the collection thread indefinitely: it held the collection lock, so
    every later poll skipped, and the daemon quietly stopped recording history
    until someone restarted it. Here the child is killed and abandoned; a reaper
    thread collects it whenever the kernel finally lets go, so no zombie is left
    behind and the caller always gets its timeout honoured.
    """
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.DEVNULL, text=True)
    except (FileNotFoundError, OSError) as e:
        log(f"run {cmd[0]} failed: {e}", level="debug")
        return ""
    try:
        out, _ = proc.communicate(timeout=timeout)
        return out or ""
    except subprocess.TimeoutExpired:
        log(f"{cmd[0]} did not answer in {timeout}s — abandoning it "
            f"(device may be wedged)")
        try:
            proc.kill()
        except OSError:
            pass
        threading.Thread(target=_reap, args=(proc,), daemon=True).start()
        return ""


def _reap(proc) -> None:
    """Wait on an abandoned child so it doesn't linger as a zombie."""
    try:
        proc.wait()
    except Exception:
        pass


def write_bytes_atomic(path: Path, data: bytes, *, mode: int = 0o644) -> bool:
    """Atomic write for binary data (poster images) — text mode would corrupt it."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".")
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
            os.chmod(tmp, mode)
            os.replace(tmp, path)
            return True
        except Exception:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    except Exception as e:
        log(f"write {path} failed: {e}", level="debug")
        return False


def write_atomic(path: Path, data: str, *, mode: int = 0o644,
                 owner: Optional[str] = None) -> bool:
    """
    Write a file so a reader never sees a half-written version: write to a temp
    file in the same directory, fix ownership/mode, then rename over the target.
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".")
        try:
            with os.fdopen(fd, "w") as f:
                f.write(data)
            os.chmod(tmp, mode)
            if owner:
                uid = uid_of(owner)
                if uid is not None:
                    try:
                        os.chown(tmp, uid, -1)
                    except PermissionError:
                        pass
            os.replace(tmp, path)
            return True
        except Exception:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    except Exception as e:
        log(f"write {path} failed: {e}", level="debug")
        return False


def write_json(path: Path, obj, **kw) -> bool:
    return write_atomic(path, json.dumps(obj, separators=(",", ":"),
                                         ensure_ascii=False), **kw)


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text())
    except Exception:
        return default


def uid_of(name: str) -> Optional[int]:
    try:
        return pwd.getpwnam(name).pw_uid
    except KeyError:
        out = run(["id", "-u", name]).strip()
        return int(out) if out.isdigit() else None


def name_of_uid(uid: int) -> str:
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def web_user() -> str:
    """
    Which user does php-fpm run as? Needed so the API token is written readable
    by the page and nobody else. On AlmaLinux php-fpm ships as 'apache' even
    when nginx serves the site, so ask the running process rather than guess.
    """
    for proc in ("php-fpm", "php-fpm8.3", "php-fpm8.2", "php-fpm8.1", "nginx", "httpd"):
        out = run(["ps", "-o", "user=", "-C", proc])
        users = {u.strip() for u in out.splitlines() if u.strip() and u.strip() != "root"}
        if users:
            return sorted(users)[0]
    return "nginx"


# ==========================================================================
# smart
# ==========================================================================

_BRIDGE_CACHE: dict = {}


def _disk_bridge(name: str) -> Optional[str]:
    """
    The USB bridge a disk hangs off, e.g. '2-1', or None for non-USB devices.
    Taken from the sysfs device path, which contains the USB device between the
    controller and the SCSI host: .../usb2/2-1/2-1:1.0/host4/.../block/sda.
    Disks sharing this value sit in the same enclosure behind the same bridge.
    """
    if name in _BRIDGE_CACHE:
        return _BRIDGE_CACHE[name]
    br = None
    try:
        path = os.path.realpath(f"/sys/block/{name}")
        m = re.search(r"/usb\d+/(\d+-[\d.]+)/", path)
        br = m.group(1) if m else None
    except OSError:
        br = None
    _BRIDGE_CACHE[name] = br
    return br


def _disk_by_id(name: str) -> Optional[str]:
    """
    The /dev/disk/by-id name for a kernel device (e.g. 'sda'), preferring a
    wwn-* entry because it's tied to the drive itself rather than the USB bridge.
    This is the stable cache key: it survives reboots (sd? letters shuffle) and
    doesn't collapse together disks that share a bridge serial.
    """
    if not name:
        return None
    d = "/dev/disk/by-id"
    if not os.path.isdir(d):
        return None
    best = None
    try:
        for entry in os.listdir(d):
            try:
                target = os.path.basename(os.readlink(os.path.join(d, entry)))
            except OSError:
                continue
            if target != name:
                continue
            if entry.startswith("wwn-"):
                return entry
            if best is None:
                best = entry
    except OSError:
        return None
    return best


def _collect_mounts(node: dict, acc: list) -> None:
    """Gather (mountpoint, fssize, fsused) from a device and all its descendants."""
    mp = node.get("mountpoint")
    if mp:
        acc.append((mp, node.get("fssize"), node.get("fsused")))
    for c in node.get("children", []):
        _collect_mounts(c, acc)


def _pick_mount(node: dict) -> tuple:
    """
    Choose the mount that best represents a disk. The root filesystem wins (it's
    what matters on the system disk), otherwise the deepest real data path —
    never a tiny helper partition like /boot/efi or /boot when something more
    meaningful is mounted on the same disk. Recurses so LVM/crypt children count.
    """
    mounts = []
    _collect_mounts(node, mounts)
    if not mounts:
        return None, None, None
    real = [m for m in mounts if m[0] and m[0] not in ("[SWAP]",)]
    if not real:
        return None, None, None
    # root always wins
    for mp, sz, us in real:
        if mp == "/":
            return mp, sz, us
    # otherwise prefer a data mount over boot/efi helpers, then the longest path
    def score(m):
        mp = m[0]
        helper = mp.startswith("/boot") or mp == "/efi"
        return (0 if helper else 1, len(mp))
    real.sort(key=score, reverse=True)
    return real[0]


def list_block_devices() -> list[dict]:
    """Physical disks with their transport and mount, via lsblk (reads sysfs)."""
    out = run(["lsblk", "-bJ", "-o",
               "NAME,PATH,SIZE,MODEL,SERIAL,TRAN,TYPE,MOUNTPOINT,FSSIZE,FSUSED"])
    try:
        tree = json.loads(out)
    except (json.JSONDecodeError, ValueError):
        return []
    devs = []
    for d in tree.get("blockdevices", []):
        if d.get("type") != "disk":
            continue
        mount, fssize, fsused = _pick_mount(d)
        d["_mount"] = mount
        d["fssize"] = fssize
        d["fsused"] = fsused
        devs.append(d)
    return devs


def diskstat(name: str) -> Optional[tuple[int, int]]:
    """(sectors read, sectors written) from /sys/block/<name>/stat — from memory."""
    try:
        parts = Path(f"/sys/block/{name}/stat").read_text().split()
        return int(parts[2]), int(parts[6])
    except (OSError, IndexError, ValueError):
        return None


def infer_power(name: str, tran: str, prev_total: Optional[int],
                idle_for: float, live_io: bool, recent_io: bool) -> tuple[str, str]:
    """
    Work out standby vs active without touching the disk. Ported from the PHP
    collector's decision so behaviour matches:

      * NVMe: always active.
      * Any I/O this poll or since the last one: active.
      * We have a baseline and it's been quiet less than the spindown timer:
        active (the disk hasn't had time to spin down yet).
      * Quiet at least the spindown timer: standby.
      * No baseline at all yet: unknown.

    The key point is the third rule: a disk read from in bursts (video playback)
    can go a poll or two without the counter moving, and it must NOT be called
    standby until it's genuinely been idle past the drive's own spindown timer.
    """
    if tran == "nvme":
        return "active", "nvme"
    if live_io or recent_io:
        return "active", "I/O since last poll"
    if prev_total is not None and idle_for < SPINDOWN_AFTER_S:
        return "active", f"idle only {int(idle_for)}s"
    if idle_for >= SPINDOWN_AFTER_S:
        return "standby", f"no I/O for {int(idle_for)}s"
    return "unknown", "no baseline yet"


# ---- SMART ---------------------------------------------------------------

# Per-device list of `smartctl -d` types known to return data, so repeat reads
# don't re-try the ones that never work on this bridge.
_SMART_TYPES_OK: dict = {}

_ATTR_RE = {
    "realloc":      "Reallocated_Sector_Ct",
    "pending":      "Current_Pending_Sector",
    "uncorrect":    "Offline_Uncorrectable",
    "reported_unc": "Reported_Uncorrect",
    "cmd_timeout":  "Command_Timeout",
    "crc_err":      "UDMA_CRC_Error_Count",
    "spin_retry":   "Spin_Retry_Count",
    "start_stop":   "Start_Stop_Count",
    "load_cycle":   "Load_Cycle_Count",
    "power_cycle":  "Power_Cycle_Count",
    "poh":          "Power_On_Hours",
    "offretract":   "Power-Off_Retract_Count",
    "lba_written":  "Total_LBAs_Written",
    "lba_read":     "Total_LBAs_Read",
}


def _attr(text: str, name: str) -> Optional[int]:
    # The daemon runs `smartctl -x`, whose attribute table is
    #   ID NAME FLAGS VALUE WORST THRESH FAIL RAW_VALUE
    # The RAW value is the last column. Grab the last number on the row, allowing
    # an optional bracket breakdown after it ("46115 (45 12 0)"). The previous
    # attempt assumed the wider `-a` layout and ended up capturing the normalized
    # VALUE column instead — which showed up as every attribute reading 100.
    m = re.search(
        r"^\s*\d+\s+" + re.escape(name) + r"\s+.+?\s+(\d+)(?:\s+\([\d\s]+\))?\s*$",
        text, re.MULTILINE)
    return int(m.group(1)) if m else None


def _attr_raw_row(text: str, name: str) -> Optional[dict]:
    m = re.search(r"^\s*(\d+)\s+" + re.escape(name) +
                  r"\s+\S+\s+(\d+)\s+(\d+)\s+(\S+)\s+\S+\s+\S+\s+\S+\s+(.+?)\s*$",
                  text, re.MULTILINE)
    if not m:
        return None
    return {"id": int(m.group(1)), "value": int(m.group(2)),
            "worst": int(m.group(3)), "thresh": m.group(4),
            "raw": m.group(5).strip()}


def _parse_temp(text: str) -> Optional[int]:
    for pat in (r"Temperature_Celsius\s+.*?(\d+)(?:\s|$)",
                r"Airflow_Temperature_Cel\s+.*?(\d+)(?:\s|$)",
                r"Current Drive Temperature:\s+(\d+)",
                r"Temperature:\s+(\d+)\s+Celsius"):
        m = re.search(pat, text)
        if m:
            return int(m.group(1))
    return None


def _parse_temp_minmax(text: str) -> tuple[Optional[int], Optional[int]]:
    m = re.search(r"Min/Max\s+Temperature:\s+(-?\d+)/(-?\d+)", text)
    if m:
        return int(m.group(1)), int(m.group(2))
    lo = re.search(r"Temperature_Celsius\s+.*?\(Min/Max\s+(-?\d+)/(-?\d+)\)", text)
    if lo:
        return int(lo.group(1)), int(lo.group(2))
    return None, None


def _parse_health(text: str) -> Optional[str]:
    m = re.search(r"(?:SMART overall-health.*?:|SMART Health Status:)\s*(\w+)", text)
    return m.group(1) if m else None


def _parse_selftest(text: str) -> Optional[str]:
    m = re.search(r"# 1\s+(.*?)\s{2,}", text)
    return m.group(1).strip() if m else None


def _nvme(text: str, label: str) -> Optional[int]:
    m = re.search(re.escape(label) + r":\s+([\d,]+)", text)
    return int(m.group(1).replace(",", "")) if m else None


MAINT_MARK = Path(os.environ.get("PLEXMON_RUN", "/run/plexmon")) / "maintenance"


def in_maintenance() -> bool:
    """Settings put this server into maintenance (plexmon_admin writes the mark)."""
    try:
        return MAINT_MARK.exists()
    except OSError:
        return False


def run_smartctl(devpath: str, tran: str) -> dict:
    """
    Read SMART, trying several -d types, merging the best of each field.

    Some USB bridges answer one -d type with only a health status and another
    with only a temperature; taking the best of each gives the fullest picture.
    THIS SPINS THE DISK UP — callers gate it on the disk already being awake.
    """
    if tran == "nvme":
        types = ["nvme"]
    else:
        types = ["sat", "sat,12", "sat,16", "usbjmicron", "auto", "scsi"]

    # Trying every -d type on every read means six smartctl processes per disk
    # per pass, most of which are known to fail on this bridge. Once we've seen
    # which ones actually return data, use only those. If they all stop working
    # (bridge swapped, disk moved) we fall back to the full list below.
    known = _SMART_TYPES_OK.get(devpath)
    attempt = known if known else types
    # A known-good type gets the full timeout; a speculative probe does not,
    # because a bridge that doesn't understand it tends to stall until timeout.
    probe_timeout = 30 if known else 12

    merged: dict = {"smart_type": "n/a", "all_attrs": {}}
    last_out = ""
    worked: list = []
    for t in attempt:
        out = run([SMARTCTL, "-x", "-d", t, devpath], timeout=probe_timeout)
        if not out or "Unknown USB bridge" in out or "please specify device type" in out:
            continue
        last_out = out
        got_any = False

        temp = _parse_temp(out)
        if temp is not None and merged.get("temp") is None:
            merged["temp"] = temp; got_any = True

        health = _parse_health(out)
        if health and merged.get("health") is None:
            merged["health"] = health
            merged["smart_ok"] = (health.upper() in ("PASSED", "OK"))
            got_any = True

        for key, attr in _ATTR_RE.items():
            if merged.get(key) is None:
                v = _attr(out, attr)
                if v is not None:
                    merged[key] = v; got_any = True

        if tran == "nvme":
            for key, label in (("poh", "Power On Hours"),
                               ("power_cycle", "Power Cycles"),
                               ("nvme_written", "Data Units Written"),
                               ("nvme_read", "Data Units Read"),
                               ("unsafe_shutdown", "Unsafe Shutdowns"),
                               ("err_log", "Error Information Log Entries"),
                               ("nvme_media_err", "Media and Data Integrity Errors")):
                if merged.get(key) is None:
                    v = _nvme(out, label)
                    if v is not None:
                        merged[key] = v; got_any = True
            # These two carry a % sign, so the plain "label: number" parse above
            # misses them. Names must match what the page reads — the endurance
            # figure used to be stored as nvme_used_pct, which nothing looked at,
            # so the card showed a dash for a value we had all along.
            for key, label in (("nvme_used", "Percentage Used"),
                               ("nvme_spare", "Available Spare")):
                if merged.get(key) is None:
                    mm = re.search(re.escape(label) + r":\s+(\d+)\s*%", out)
                    if mm:
                        merged[key] = int(mm.group(1)); got_any = True
            # An NVMe has no spinning platters, so the ATA attribute table is
            # empty. Give the "All SMART values" expander something real to show.
            for label, key in (("Critical Warning", "nvme_crit_warn"),
                               ("Available Spare Threshold", "nvme_spare_thresh"),
                               ("Host Read Commands", "nvme_host_reads"),
                               ("Host Write Commands", "nvme_host_writes"),
                               ("Controller Busy Time", "nvme_busy_time"),
                               ("Warning  Comp. Temperature Time", "nvme_warn_temp_time"),
                               ("Critical Comp. Temperature Time", "nvme_crit_temp_time")):
                mm = re.search(re.escape(label) + r":\s+(\S+)", out)
                if mm and label not in merged["all_attrs"]:
                    merged["all_attrs"][label.strip()] = {
                        "id": 0, "value": 0, "worst": 0, "thresh": "—",
                        "raw": mm.group(1).rstrip("%")}
                    got_any = True

        # The drive's own temperature limits, when it publishes them. NVMe media
        # is rated far hotter than a hard disk — this one warns at 77 °C, while
        # our global default warns at 60 — so judging it by the spinning-disk
        # thresholds would raise an alarm over a perfectly healthy SSD.
        for key, pat in (("temp_warn_own", r"Warning\s+Comp\.\s+Temp\.\s+Threshold:\s+(\d+)"),
                         ("temp_crit_own", r"Critical\s+Comp\.\s+Temp\.\s+Threshold:\s+(\d+)")):
            if merged.get(key) is None:
                mm = re.search(pat, out)
                if mm:
                    merged[key] = int(mm.group(1))

        tmin, tmax = _parse_temp_minmax(out)
        if tmin is not None and merged.get("tmin") is None:
            merged["tmin"], merged["tmax"] = tmin, tmax; got_any = True

        st = _parse_selftest(out)
        if st and merged.get("selftest") is None:
            merged["selftest"] = st; got_any = True

        mm = re.search(r"Model Family:\s+(.+)", out) or re.search(r"Device Model:\s+(.+)", out) \
            or re.search(r"Model Number:\s+(.+)", out)
        if mm and merged.get("real_model") is None:
            merged["real_model"] = mm.group(1).strip()
        sn = re.search(r"Serial Number:\s+(.+)", out)
        if sn and merged.get("real_serial") is None:
            merged["real_serial"] = sn.group(1).strip()

        # full attribute table, for the "All SMART values" expander on the page
        for line in out.splitlines():
            # Handle both `-x` (ID NAME FLAGS VALUE WORST THRESH FAIL RAW) and
            # `-a` (…THRESH TYPE UPDATED WHEN_FAILED RAW): match up to THRESH, then
            # take everything after it and pull the RAW value (last number, before
            # an optional bracket breakdown) out of that tail.
            row = re.match(
                r"^\s*(\d+)\s+([\w-]+)\s+\S+\s+(\d+)\s+(\d+)\s+(\S+)\s+(.+?)\s*$",
                line)
            if row and row.group(2) not in merged["all_attrs"]:
                tail = row.group(6)
                rm = re.search(r"(\d+)(?:\s+\([\d\s]+\))?\s*$", tail)
                raw = rm.group(1) if rm else tail.strip().split()[-1]
                merged["all_attrs"][row.group(2)] = {
                    "id": int(row.group(1)), "value": int(row.group(3)),
                    "worst": int(row.group(4)), "thresh": row.group(5),
                    "raw": raw}
                got_any = True

        if got_any:
            worked.append(t)
            if merged["smart_type"] == "n/a":
                merged["smart_type"] = t

        # Stop as soon as this type gave us the essentials. Merging across every
        # type exists for bridges that scatter the data (health from one, temp
        # from another); when one type answers fully there is nothing to gain
        # from five more invocations — and on a USB bridge the failing ones stall
        # for seconds each, which is what made the first wake after a restart
        # take longer than the page was willing to wait.
        if (merged.get("health") is not None and merged.get("temp") is not None
                and merged["all_attrs"]):
            break

    if worked:
        _SMART_TYPES_OK[devpath] = worked
    elif known:
        # the remembered types stopped working — forget them and retry in full
        _SMART_TYPES_OK.pop(devpath, None)
        return run_smartctl(devpath, tran)

    # Fallback: if a key numeric field didn't parse from the per-attribute pass
    # but the full attribute table has it, take the first integer of its raw
    # value. This is what rescues Power-on hours (and similar) on drives whose
    # raw column carries a suffix the direct parser tripped over.
    attr_map = {"poh": "Power_On_Hours", "start_stop": "Start_Stop_Count",
                "load_cycle": "Load_Cycle_Count", "power_cycle": "Power_Cycle_Count",
                "realloc": "Reallocated_Sector_Ct", "pending": "Current_Pending_Sector",
                "uncorrect": "Offline_Uncorrectable", "crc_err": "UDMA_CRC_Error_Count",
                "reported_unc": "Reported_Uncorrect"}
    for field, attr in attr_map.items():
        if merged.get(field) is None and attr in merged["all_attrs"]:
            raw = str(merged["all_attrs"][attr].get("raw", ""))
            mnum = re.match(r"\s*(\d+)", raw)
            if mnum:
                merged[field] = int(mnum.group(1))

    # SCSI/SAS drives report hours in prose rather than the attribute table —
    # the same fallbacks the PHP parse_poh() had.
    if merged.get("poh") is None:
        for pat in (r"Power On Hours:\s*([\d,]+)",
                    r"number of hours powered up\s*=\s*([\d.]+)"):
            mm = re.search(pat, last_out, re.I) if last_out else None
            if mm:
                merged["poh"] = int(float(mm.group(1).replace(",", "")))
                break

    # Worst pre-fail margin (VALUE − THRESH): the "Closest to threshold" row in
    # All SMART values. Pre-fail rows are flagged 'P…' in -x FLAGS or labelled
    # 'Pre-fail' in the -a TYPE column.
    worst = None
    worst_attr = None
    if last_out:
        for line in last_out.splitlines():
            mm = re.match(r"^\s*\d+\s+([\w-]+)\s+(\S+)\s+(\d+)\s+\d+\s+(\d+)", line)
            if not mm:
                continue
            flags = mm.group(2)
            prefail = flags.startswith("P") or "Pre-fail" in line
            if not prefail:
                continue
            margin = int(mm.group(3)) - int(mm.group(4))
            if worst is None or margin < worst:
                worst, worst_attr = margin, mm.group(1)
    if worst is not None:
        merged["margin"] = worst
        merged["margin_attr"] = worst_attr

    return merged


# ==========================================================================
# disks
# ==========================================================================

class DiskMonitor:
    def __init__(self) -> None:
        self.cache: dict = read_json(CACHE_FILE, {}) or {}
        # Restore which `smartctl -d` types work for each device. Without this the
        # memory is rebuilt from scratch after every restart, and the first wake
        # pays a full six-type probe per disk — slow enough that the page gave up
        # waiting and reported no SMART refresh until a second click.
        saved = (self.cache.get("__meta") or {}).get("smart_types")
        if isinstance(saved, dict):
            _SMART_TYPES_OK.update({k: v for k, v in saved.items()
                                    if isinstance(v, list) and v})
        # per-device rolling I/O state, keyed by kernel name
        self._io: dict[str, dict] = {}
        # when WE last spun a disk up by reading SMART — reporting only, never a
        # reason to read SMART again (see mark_awake)
        self._smart_woke: dict[str, float] = {}
        # when SMART was last actually read per device, for throttling
        self._last_smart: dict[str, float] = {}
        # did we report this disk as standby since its last SMART read? used to
        # sanity-check SPINDOWN_AFTER_S against the drive's real behaviour
        self._saw_standby: dict[str, bool] = {}
        self._last_serial: dict[str, str] = {}

    # -- cache keyed by serial, because sd? letters shuffle across reboots --
    def _key(self, dev: dict) -> str:
        """
        One stable key used for BOTH writing and reading the cache. Prefer the
        /dev/disk/by-id name (a wwn-* symlink is tied to the drive itself), then
        the real drive serial once we've read SMART, then the lsblk serial, then
        the mount. This must be computed the same way on every path — keying the
        write by one thing and the read by another is what made cached SMART
        vanish on the USB-bridged disks, whose lsblk 'serial' is the bridge's
        (shared by all of them), not the drive's.
        """
        byid = _disk_by_id(dev.get("name", ""))
        return (byid or dev.get("_real_serial") or dev.get("serial")
                or dev.get("_mount") or dev.get("name") or "?")

    def _cached(self, key: str) -> dict:
        entry = self.cache.get(key)
        return dict(entry) if isinstance(entry, dict) else {}

    def sample_io(self, devs: list[dict]) -> None:
        """Take an I/O snapshot for every disk. Pure memory read; wakes nothing."""
        now = time.time()
        for d in devs:
            name = d["name"]
            st = diskstat(name)
            if st is None:
                continue
            r, w = st
            total = r + w
            prev = self._io.get(name)
            if prev is None:
                # First time we've seen this disk. We have no idea how long it
                # has been idle, so seed changed_at far in the past — otherwise a
                # freshly-observed sleeping disk would look "recently active".
                self._io[name] = {"total": total, "last_total": total,
                                  "r": r, "w": w, "dr": 0, "dw": 0,
                                  "changed_at": now - SPINDOWN_AFTER_S - 1,
                                  "ever_changed": False, "changed_since_poll": False}
            else:
                # changed_since_poll: did the absolute counter move since the
                # PREVIOUS collect? This is the PHP recent_io test and has no time
                # window — a disk being read from is active even if the reads come
                # in bursts spaced further apart than a poll interval.
                prev["changed_since_poll"] = (total != prev["last_total"])
                prev["last_total"] = total
                # per-direction deltas drive the Reading/Writing badge
                prev["dr"] = max(0, r - prev.get("r", r))
                prev["dw"] = max(0, w - prev.get("w", w))
                prev["r"], prev["w"] = r, w
                if total != prev["total"]:
                    prev["total"] = total
                    prev["changed_at"] = now
                    prev["ever_changed"] = True

    def mark_awake(self, name: str) -> None:
        """
        Record that WE spun this disk up by reading SMART.

        Deliberately kept out of the I/O bookkeeping. Feeding this back into
        `changed_at` created a loop that never ended: the SMART read looked like
        activity, activity meant "disk is awake, safe to read SMART", and the
        next read renewed it — so the daemon polled SMART every 10 s forever and
        the drives could never spin down. This timestamp only informs what state
        we *report*; whether we may read SMART stays tied to real disk I/O.
        """
        self._smart_woke[name] = time.time()

    def _io_state(self, name: str) -> tuple[Optional[int], float, bool, bool]:
        """(current total, idle seconds, live this poll, changed since last poll)."""
        st = self._io.get(name)
        if st is None:
            return None, SPINDOWN_AFTER_S + 1, False, False
        idle = time.time() - st["changed_at"]
        live = st.get("ever_changed", False) and idle < FAST_INTERVAL * 1.5
        changed = st.get("changed_since_poll", False)
        return st["total"], idle, live, changed

    def collect(self, *, force: bool = False, read_smart: bool = True,
                align_smart: bool = False) -> list[dict]:
        """
        Build the per-disk records. `force` reads SMART even from a sleeping
        disk (used by the daily sweep and wake requests). With read_smart False
        the disks are reported purely from I/O state and cache — no smartctl at
        all — which is what the fast loop uses between SMART reads.
        """
        devs = list_block_devices()
        self.sample_io(devs)
        out = []

        # Per-disk I/O state, then — if the bridge powers a whole enclosure —
        # merged across each bridge group. A multi-bay bridge spins every bay up
        # together, so a disk whose siblings are busy is physically turning even
        # though nothing addressed it: its own counters stay flat while the
        # platters are moving. Sharing the group's freshest idle time makes the
        # reported state match the hardware, and lets SMART be read from a disk
        # that is already spinning at no extra cost.
        st_by_dev: dict[str, dict] = {}
        for d in devs:
            name = d["name"]
            total, idle, live, changed = self._io_state(name)
            recent = live or changed or (
                self._io.get(name, {}).get("ever_changed", False)
                and idle < FAST_INTERVAL * 3)
            st_by_dev[name] = {"total": total, "idle": idle, "live": live,
                               "recent": recent, "via_bridge": None}

        if BRIDGE_WAKES_SIBLINGS:
            groups: dict[str, list] = {}
            for d in devs:
                if (d.get("tran") or "").lower() != "usb":
                    continue
                br = _disk_bridge(d["name"])
                if br:
                    groups.setdefault(br, []).append(d["name"])
            for br, members in groups.items():
                if len(members) < 2:
                    continue
                busiest = min(members, key=lambda n: st_by_dev[n]["idle"])
                min_idle = st_by_dev[busiest]["idle"]
                any_live = any(st_by_dev[n]["live"] for n in members)
                any_recent = any(st_by_dev[n]["recent"] for n in members)
                for n in members:
                    s = st_by_dev[n]
                    if s["idle"] > min_idle:
                        s["idle"] = min_idle
                        s["via_bridge"] = (br, busiest)
                    if any_live and not s["live"]:
                        s["live"] = True
                        s["via_bridge"] = s["via_bridge"] or (br, busiest)
                    if any_recent and not s["recent"]:
                        s["recent"] = True
                        s["via_bridge"] = s["via_bridge"] or (br, busiest)

        for d in devs:
            name = d["name"]
            tran = (d.get("tran") or "").lower()
            key = self._key(d)
            st = st_by_dev.get(name, {})
            total, idle = st.get("total"), st.get("idle", SPINDOWN_AFTER_S + 1)
            live, recent = st.get("live", False), st.get("recent", False)
            have_baseline = total is not None

            power, psrc = infer_power(name, tran, total, idle, live, recent)
            # Say plainly when a disk is only spinning because a bridge sibling
            # is: it explains an "active" disk with no I/O of its own.
            if st.get("via_bridge") and power == "active":
                br, busiest = st["via_bridge"]
                psrc = f"spun up with {busiest} on bridge {br}"
            # A disk we spun up ourselves is genuinely turning, even though the
            # SMART read left no trace in the kernel I/O counters. Report that
            # for as long as the drive's own spindown timer would keep it up.
            # This is presentation only — `awake_certain` below still depends on
            # real I/O, so it can't turn into a reason to keep polling SMART.
            woke = self._smart_woke.get(name)
            if woke is not None and tran != "nvme":
                since = time.time() - woke
                if since < SPINDOWN_AFTER_S:
                    if power != "active":
                        power = "active"
                        psrc = f"spun up {int(since)}s ago"
                else:
                    self._smart_woke.pop(name, None)
            iost = self._io.get(name, {})
            io = "write" if iost.get("dw", 0) > 0 else (
                 "read" if iost.get("dr", 0) > 0 else "idle")

            # Record what we actually REPORT (after any override), not what the
            # raw inference said — this flag exists to be compared against the
            # drive's own spin-up counter, so it has to match what the user saw.
            if power == "standby":
                self._saw_standby[name] = True

            awake_certain = (tran == "nvme") or live or recent
            # Don't re-read SMART on every tick just because a disk is busy: the
            # values change on the order of minutes, not seconds, and each read
            # costs several smartctl processes. Forced passes bypass this.
            last_read = self._last_smart.get(name, 0.0)
            # Read on the pass that writes a history sample, so every sample
            # carries fresh counters. Without this the two cadences drift past
            # each other and most samples record nothing — which is why the
            # per-day charts came out as isolated dots instead of lines. Both
            # intervals default to 300 s, so this aligns the reads rather than
            # adding any.
            due = align_smart or (time.time() - last_read) >= SMART_MIN_INTERVAL
            # In maintenance (Settings → Upgrades and maintenance, 2.3.0) no
            # routine read: smartctl touches no disk that is being worked on.
            may_read = read_smart and (force or (awake_certain and due and not in_maintenance()))

            rec = {
                "dev": name,
                "path": d.get("path"),
                "mount": d.get("_mount"),
                "tran": tran,
                "serial": d.get("serial"),
                # A stable, UNIQUE key for history/charts. Never the lsblk serial:
                # USB-bridged disks all report the bridge's serial, which would
                # collapse every disk into one chart line (that's why Trends only
                # showed /data). by-id is per-drive; mount and dev are unique
                # fallbacks.
                "hist_key": (_disk_by_id(name) or d.get("_mount")
                             or d.get("path") or name),
                "model": d.get("model"),
                "size": self._human_size(d.get("size")),
                "size_b": d.get("size"),
                "fs_size_b": d.get("fssize"),
                "fs_used_b": d.get("fsused"),
                "power": power,
                # No hdparm on this bridge, so power is always inferred from I/O
                # counters. The 'inferred:' prefix and power_reliable=False are
                # what the page keys its "state is inferred" tooltip note on.
                "power_src": ("inferred: " + psrc) if tran != "nvme" else psrc,
                "power_reliable": tran == "nvme",
                "idle_for_s": int(idle),
                "io": io,
            }
            if d.get("fssize") and d.get("fsused"):
                try:
                    size_b = int(d["fssize"])
                    used_b = int(d["fsused"])
                    rec["fs_pct"] = round(used_b / size_b * 100)
                    rec["fs_size"] = self._human_size(size_b)
                    rec["fs_used"] = self._human_size(used_b)
                except (ValueError, ZeroDivisionError):
                    rec["fs_pct"] = None

            if may_read:
                sm = run_smartctl(d["path"], tran)
                if sm.get("smart_type", "n/a") != "n/a":
                    rec.update(sm)
                    rec["from_cache"] = False
                    rec["smart_stale"] = False
                    rec["cache_age"] = 0
                    rec["read_at"] = int(time.time())
                    self._last_smart[name] = time.time()
                    # Reading SMART spins the disk up, but smartctl talks to it
                    # over SG_IO, which does NOT increment /sys/block/*/stat. So
                    # mark the disk awake explicitly — otherwise a disk we just
                    # woke (via the wake button / daily sweep) would look idle and
                    # be reported as standby minutes later while it's still spinning.
                    self.mark_awake(name)
                    # Only claim the read is what woke it when nothing else did:
                    # for a disk already busy with real I/O, "I/O since last poll"
                    # is the truthful and more useful explanation.
                    if power != "active":
                        rec["power"] = "active"
                        rec["power_src"] = "just read SMART (disk spun up)"
                    # Key the write with the SAME function the read uses. Feed the
                    # real serial in first so _key can prefer by-id/real-serial
                    # consistently on both sides.
                    d["_real_serial"] = sm.get("real_serial")
                    ck = self._key(d)
                    # "SMART OK for X" — track when the error counters last moved.
                    # Compare against the previous cache entry BEFORE overwriting.
                    prev_entry = self.cache.get(ck) or {}
                    # Sanity-check SPINDOWN_AFTER_S against reality. Start_Stop_Count
                    # rises every time the drive spins up. If it rose since our last
                    # read while we never once reported this disk as standby, the
                    # drive parked and restarted behind our back — i.e. its real
                    # spindown timer is shorter than what we assume, and the state
                    # we show is wrong. Nothing else can catch this: we deliberately
                    # never ask the drive its power state.
                    prev_ss = prev_entry.get("start_stop")
                    new_ss = sm.get("start_stop")
                    if (prev_ss is not None and new_ss is not None
                            and new_ss > prev_ss and not self._saw_standby.get(name)):
                        rec["spindown_mismatch"] = True
                        log(f"{name}: spun up {new_ss - prev_ss}× since the last "
                            f"read although we never reported standby — the real "
                            f"spindown timer looks shorter than SPINDOWN_AFTER_S "
                            f"({SPINDOWN_AFTER_S}s); consider lowering it")
                    self._saw_standby[name] = False
                    # Which counters count as "errors" depends on the medium.
                    # An NVMe has none of the ATA sector attributes, so watching
                    # those left it with nothing to track and the card never got
                    # its "no error-counter change in ..." line. Flash reports
                    # its own equivalents.
                    if tran == "nvme":
                        counters = [sm.get("nvme_media_err"), sm.get("err_log")]
                    else:
                        counters = [sm.get("realloc"), sm.get("pending"),
                                    sm.get("uncorrect"), sm.get("reported_unc"),
                                    sm.get("crc_err")]
                    prev_counters = prev_entry.get("counters")
                    counters_ts = int(prev_entry.get("counters_ts") or time.time())
                    if prev_counters is not None and counters != prev_counters:
                        counters_ts = int(time.time())
                        log(f"{name}: SMART error counters changed", level="debug")
                    entry = {**sm, "cached_at": int(time.time()),
                             "dev": name, "mount": d.get("_mount")}
                    if None not in counters:
                        entry["counters"] = counters
                        entry["counters_ts"] = counters_ts
                    self.cache[ck] = entry
                    if _SMART_TYPES_OK:
                        self.cache.setdefault("__meta", {})["smart_types"] = \
                            dict(_SMART_TYPES_OK)
                    rec["stable_since"] = counters_ts
                else:
                    self._from_cache(rec, key)
            else:
                self._from_cache(rec, key)

            out.append(rec)

        # Prefer what the DRIVE reports over the USB bridge's generics: the
        # bridge advertises "USB3.0 DISKnn" and one shared serial for every bay,
        # while SMART gives the real model and serial. Keep the bridge name as
        # "enclosure" the way the PHP collector did.
        for rec in out:
            rec["enclosure"] = rec.get("model") or None
            if rec.get("real_model"):
                rec["model"] = rec["real_model"]
            if rec.get("real_serial"):
                rec["serial"] = rec["real_serial"]

        # The page reads a fixed set of SMART fields; make sure each disk record
        # has them all (null when a drive doesn't report that attribute) so the
        # template never trips over a missing key.
        optional = ("realloc", "pending", "uncorrect", "reported_unc", "crc_err",
                    "spin_retry", "cmd_timeout", "offretract", "spinup_ms",
                    "power_cycle", "start_stop", "load_cycle", "poh",
                    "lba_written", "lba_read", "margin", "margin_attr", "selftest",
                    "tmin", "tmax", "nvme_written", "nvme_read", "nvme_used",
                    "nvme_spare", "nvme_media_err", "unsafe_shutdown", "err_log",
                    "temp", "health", "smart_ok", "fs_pct", "fs_size", "fs_used",
                    "smart_stale", "temp_warn_own", "temp_crit_own",
                    "temp_warn_eff", "temp_crit_eff")
        for rec in out:
            for k in optional:
                rec.setdefault(k, None)
            # USB bridge that passes only a health verdict, nothing else — the
            # page shows "bridge exposes health only" for these.
            w, c = temp_limits(rec)
            rec["temp_warn_eff"], rec["temp_crit_eff"] = w, c
            rec["smart_limited"] = (
                rec.get("health") is not None and rec.get("temp") is None
                and rec.get("poh") is None and rec.get("realloc") is None
                and rec.get("pending") is None and rec.get("uncorrect") is None)
            rec.setdefault("stable_since", None)

        self._prune_cache(out)
        write_json(CACHE_FILE, self.cache, mode=0o600)
        return out

    @staticmethod
    def _human_size(b) -> str:
        try:
            b = int(b)
        except (TypeError, ValueError):
            return "?"
        for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
            if b < 1000:
                return f"{b:.0f} {unit}" if unit == "B" else f"{b:.1f} {unit}"
            b /= 1000
        return f"{b:.1f} EB"

    def _from_cache(self, rec: dict, key: str) -> None:
        """Fill a record from the last good SMART read, flagged as cached."""
        # Use the key we were given — it's the same _key() used on write. Falling
        # back to the lsblk serial here was the bug: on USB-bridged disks that's
        # the bridge's serial, which never matches the by-id write key.
        entry = self.cache.get(key)
        if not entry:
            # tolerate older cache entries written under a bare serial
            entry = self._cached(rec.get("serial") or "")
        if entry:
            for k, v in entry.items():
                if k not in ("cached_at", "dev", "mount", "counters", "counters_ts"):
                    rec.setdefault(k, v)
            if entry.get("counters_ts"):
                rec.setdefault("stable_since", int(entry["counters_ts"]))
            rec["from_cache"] = True
            # Only report an age if we have a real timestamp. An entry inherited
            # from the old PHP cache has no cached_at, and time()-0 would render
            # as "20658d ago" — better to show nothing than a nonsense figure.
            cached_at = int(entry.get("cached_at", 0) or 0)
            rec["cache_age"] = (int(time.time()) - cached_at) if cached_at > 0 else None
            # Being served from cache is not the same as being out of date.
            # Routine reads are throttled to SMART_MIN_INTERVAL, so a disk read
            # moments ago is served from cache on the very next poll while still
            # being completely current. Only call it stale once it actually is —
            # otherwise a freshly woken disk looked out of date seconds later.
            age = rec.get("cache_age")
            rec["smart_stale"] = age is None or age > SMART_MIN_INTERVAL
        else:
            rec["from_cache"] = True
            rec["smart_stale"] = True
            rec["health"] = None
            rec["smart_ok"] = None
            rec["temp"] = None

    def _prune_cache(self, current: list[dict]) -> None:
        keep = {r.get("serial") for r in current if r.get("serial")}
        keep |= {r.get("real_serial") for r in current if r.get("real_serial")}
        # keep __meta and anything still present; drop vanished drives
        for k in list(self.cache):
            if k == "__meta":
                continue
            if k not in keep and not any(
                    (self.cache[k].get("mount") == r.get("mount")) for r in current):
                pass  # keep by default; disks that briefly disappear shouldn't lose history

    # -- wake probe files, created while a disk is up during a forced run --
    def create_probes(self, disks: list[dict]) -> None:
        for d in disks:
            mp = d.get("mount")
            if not mp or mp == "/" or d.get("tran") == "nvme":
                continue
            probe = Path(mp) / ".wake-probe"
            try:
                if probe.is_file() and probe.stat().st_size >= 65536:
                    continue
                probe.write_bytes(b"\0" * (1024 * 1024))
                probe.chmod(0o644)
                log(f"created wake probe {probe}", level="debug")
            except OSError as e:
                log(f"probe {probe}: {e}", level="debug")

    def mark_smart_read(self, disks: list[dict]) -> int:
        """Persist when SMART was genuinely read, surviving later cached runs."""
        n = sum(1 for d in disks
                if not d.get("from_cache") and d.get("tran") != "nvme"
                and d.get("smart_type", "n/a") != "n/a")
        if n:
            self.cache.setdefault("__meta", {})["last_smart_read"] = int(time.time())
            write_json(CACHE_FILE, self.cache, mode=0o600)
        return n

    @property
    def last_smart_read(self) -> int:
        return int(self.cache.get("__meta", {}).get("last_smart_read", 0))


# ==========================================================================
# system
# ==========================================================================

def read_system() -> dict:
    out = {"load": [0.0, 0.0, 0.0], "mem_total": 0, "mem_used": 0,
           "cpu_temp": None, "uptime_s": 0, "ncpu": os.cpu_count() or 1,
           "kernel": ""}
    try:
        out["load"] = list(os.getloadavg())
    except OSError:
        pass
    try:
        mem = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            k, _, v = line.partition(":")
            mem[k] = int(v.strip().split()[0]) * 1024  # kB -> bytes
        total = mem.get("MemTotal", 0)
        avail = mem.get("MemAvailable", mem.get("MemFree", 0))
        out["mem_total"] = total
        out["mem_used"] = total - avail
    except (OSError, ValueError):
        pass
    out["cpu_temp"] = _cpu_temp()
    try:
        out["uptime_s"] = int(float(Path("/proc/uptime").read_text().split()[0]))
    except (OSError, ValueError):
        pass
    try:
        out["kernel"] = Path("/proc/sys/kernel/osrelease").read_text().strip()
    except OSError:
        pass
    return out


def _cpu_temp():
    """Highest thermal-zone / hwmon reading, in °C."""
    best = None
    for tz in Path("/sys/class/thermal").glob("thermal_zone*/temp"):
        try:
            v = int(tz.read_text().strip()) / 1000.0
            if best is None or v > best:
                best = v
        except (OSError, ValueError):
            pass
    if best is None:
        for h in Path("/sys/class/hwmon").glob("hwmon*/temp*_input"):
            # Never drivetemp (2.7.1): reading it sends a command to the disk
            # and can wake a sleeping one - and it is not the processor.
            try:
                if (h.parent / "name").read_text().strip() == "drivetemp":
                    continue
            except OSError:
                pass
            try:
                v = int(h.read_text().strip()) / 1000.0
                if best is None or v > best:
                    best = v
            except (OSError, ValueError):
                pass
    return round(best) if best is not None else None


def temp_limits(d: dict) -> tuple[int, int]:
    """
    Effective (warn, crit) for one disk, in order of authority:

      1. what the drive itself publishes — it knows its own rating
      2. the NVMe defaults, for flash that publishes nothing
      3. the global defaults, meant for spinning disks

    Resolved once here so the daemon's verdict and the page's colouring can
    never disagree about where the line is.
    """
    own_w, own_c = d.get("temp_warn_own"), d.get("temp_crit_own")
    if own_w and own_c:
        return int(own_w), int(own_c)
    if (d.get("tran") or "").lower() == "nvme":
        return int(own_w or TEMP_WARN_NVME), int(own_c or TEMP_CRIT_NVME)
    return int(own_w or TEMP_WARN), int(own_c or TEMP_CRIT)


def assess(disks: list[dict], system: dict) -> tuple[str, list[dict]]:
    """
    Reduce everything to (overall, reasons). Ported verbatim from the PHP so the
    dashboard's colour and messages don't change. Severity order: crit > warn > ok.
    """
    reasons: list[dict] = []
    level = "ok"

    def bump(new):
        nonlocal level
        order = {"ok": 0, "warn": 1, "crit": 2}
        if order[new] > order[level]:
            level = new

    for d in disks:
        tag = d.get("mount") or d.get("dev")
        if d.get("smart_ok") is False:
            reasons.append({"level": "crit", "text": f"{tag}: SMART reports FAILED"})
            bump("crit")
        temp = d.get("temp")
        if temp is not None:
            # Prefer the limits the drive itself publishes. NVMe media is rated
            # much hotter than a hard disk, so the global spinning-disk defaults
            # would flag a perfectly healthy SSD as warm.
            t_warn, t_crit = temp_limits(d)
            if temp >= t_crit:
                reasons.append({"level": "crit", "text": f"{tag}: {temp} °C (critical)"})
                bump("crit")
            elif temp >= t_warn:
                reasons.append({"level": "warn", "text": f"{tag}: {temp} °C (warm)"})
                bump("warn")
        for attr, txt, sev in (
                ("realloc", "reallocated sectors", "warn"),
                ("pending", "pending sectors", "warn"),
                ("uncorrect", "uncorrectable sectors", "crit"),
                ("reported_unc", "reported uncorrectable errors", "warn"),
                ("spin_retry", "spin-retry events", "crit")):
            v = d.get(attr)
            if v:
                reasons.append({"level": sev, "text": f"{tag}: {v} {txt}"})
                bump(sev)
        if d.get("crc_err"):
            reasons.append({"level": "warn",
                            "text": f"{tag}: {d['crc_err']} UDMA CRC errors (cable/bridge)"})
            bump("warn")
        # filesystem fill only warns on the system volume; data disks are meant
        # to sit near-full on purpose
        if d.get("mount") == "/" and d.get("fs_pct") is not None and d["fs_pct"] >= 90:
            reasons.append({"level": "warn", "text": f"/: {d['fs_pct']} % full"})
            bump("warn")

    if system.get("mem_total"):
        used_pct = system["mem_used"] / system["mem_total"] * 100
        if used_pct >= 95:
            reasons.append({"level": "warn", "text": f"memory {round(used_pct)} % used"})
            bump("warn")
    if system.get("cpu_temp") and system["cpu_temp"] >= 85:
        reasons.append({"level": "warn", "text": f"CPU {system['cpu_temp']} °C"})
        bump("warn")

    return level, reasons


# ==========================================================================
# plex
# ==========================================================================

import urllib.request
import urllib.parse



def plex_token() -> Optional[str]:
    try:
        prefs = PLEX_PREFS.read_text()
    except OSError:
        return None
    m = re.search(r'PlexOnlineToken="([^"]+)"', prefs)
    return m.group(1) if m else None


def _api(path: str, token: str, timeout: float = 5.0, as_json: bool = True):
    sep = "&" if "?" in path else "?"
    url = f"{PLEX_URL}{path}{sep}X-Plex-Token={urllib.parse.quote(token)}"
    # Only ask for JSON when we actually want JSON. Sending this header on an
    # image request can make Plex return a JSON error instead of the poster.
    headers = {"Accept": "application/json"} if as_json else {}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read()
    except Exception as e:
        log(f"plex {path}: {e}", level="debug")
        return None
    if not as_json:
        return body
    try:
        return json.loads(body)
    except (json.JSONDecodeError, ValueError):
        return None


def server_info(token: Optional[str]) -> dict:
    info = {"active": None, "version": None, "web_version": None}
    if not token:
        info["active"] = _plex_running()
        return info
    j = _api("/identity", token)
    if j:
        mc = j.get("MediaContainer", {})
        info["active"] = True
        info["version"] = mc.get("version")
    else:
        info["active"] = _plex_running()
    info["web_version"] = _web_version(token)
    return info


def _web_version(token: Optional[str]) -> Optional[str]:
    """
    Version of the served web client. Plex names its JS/CSS assets like
    '…-plex-4.160.0-<hash>.js', so the version is in the served HTML.
    """
    if not token:
        return None
    for path in ("/web/index.html", "/web/", "/web/index.htm"):
        body = _api(path, token, as_json=False)
        if not body:
            continue
        if isinstance(body, (bytes, bytearray)):
            body = body.decode("utf-8", "ignore")
        m = re.search(r"-plex-(\d+\.\d+\.\d+)-[0-9a-f]+\.(?:js|css)", body, re.I)
        if m:
            return m.group(1)
        m = re.search(r'"?version"?\s*[:=]\s*["\']?(4\.\d+\.\d+)', body, re.I)
        if m:
            return m.group(1)
    return None


def _plex_running() -> bool:
    return bool(run(["pgrep", "-x", "Plex Media Server"]).strip())


def mount_list() -> list[str]:
    out = []
    try:
        for line in Path("/proc/self/mounts").read_text().splitlines():
            f = line.split()
            if len(f) >= 3 and f[2] in ("ext4", "xfs", "btrfs", "ext3", "zfs"):
                out.append(f[1].replace("\\040", " "))
    except OSError:
        pass
    out.sort(key=len, reverse=True)  # longest prefix wins
    return out


# ---- now playing ---------------------------------------------------------

def sessions(token: Optional[str], mounts: list[str]) -> list[dict]:
    if not token:
        return []
    j = _api("/status/sessions", token)
    items = (j or {}).get("MediaContainer", {}).get("Metadata", []) or []
    out = []
    for m in items:
        media = (m.get("Media") or [{}])[0]
        part = (media.get("Part") or [{}])[0]
        player = m.get("Player", {})
        sess = m.get("Session", {})
        user = m.get("User", {})

        # Plex only puts `decision` on streams during a transcode; on direct play
        # it is on the Part, and with neither it isn't converting anything.
        part_dec = part.get("decision") or media.get("decision")
        fallback = part_dec or (None if "TranscodeSession" in m else "directplay")

        streams = {"1": None, "2": None, "3": None}
        for s in part.get("Stream", []):
            t = str(s.get("streamType", ""))
            # membership test, not truthiness: the slots start out None
            if t not in streams or streams[t] is not None:
                continue
            if t != "1" and not s.get("selected"):
                continue
            streams[t] = {"title": s.get("displayTitle") or s.get("extendedDisplayTitle"),
                          "decision": s.get("decision") or fallback}

        file = part.get("file")
        vol = None
        if file:
            for mp in mounts:
                if mp != "/" and file.startswith(mp.rstrip("/") + "/"):
                    vol = mp
                    break
            if vol is None and file.startswith("/"):
                vol = "/"

        out.append({
            "type": m.get("type"), "title": m.get("title"),
            "show": m.get("grandparentTitle") or m.get("parentTitle"),
            "season": _int(m.get("parentIndex")), "episode": _int(m.get("index")),
            "year": _int(m.get("year")),
            "duration_ms": _int(m.get("duration")), "offset_ms": _int(m.get("viewOffset")) or 0,
            "state": player.get("state"), "user": user.get("title"),
            "product": player.get("product"), "player": player.get("title"),
            "address": player.get("address"), "local": bool(player.get("local")),
            "bandwidth": _int(sess.get("bandwidth")),
            "video": (streams["1"] or {}).get("title"),
            "video_dec": (streams["1"] or {}).get("decision"),
            "audio": (streams["2"] or {}).get("title"),
            "audio_dec": (streams["2"] or {}).get("decision"),
            "subs": (streams["3"] or {}).get("title"),
            "subs_dec": (streams["3"] or {}).get("decision"),
            "volume": vol,
            "art": m.get("grandparentThumb") or m.get("parentThumb") or m.get("thumb"),
            # filled in below when an Apple TV is reachable at the player's address
            "atv": None,
        })
    return out


def attach_atv(sessions_list: list) -> None:
    """
    Note which Apple TV, if any, is playing each stream. Plex reports the
    player's address and the scan gives every device's address, so matching on
    that is exact — unlike names, which are not guaranteed unique.
    """
    ok, _ = atv_ready()
    if not ok:
        return
    for s in sessions_list:
        addr = s.get("address")
        dev = atv_for_address(addr)
        if dev:
            s["atv"] = {"ident": dev["ident"], "name": dev["name"],
                        "paired": dev["paired"], "kind": "appletv"}
            # Open the session now, in the background. Otherwise the first press
            # still waits out a full handshake and only later presses feel quick.
            if dev["paired"]:
                atv_warm(dev["ident"], dev.get("address"))
            continue
        # Not an Apple TV — try the other makes at the same address.
        other = tv_for_address(addr)
        if other:
            s["atv"] = {"ident": addr, "name": other["name"],
                        "paired": other["paired"], "kind": other["kind"]}


def cache_art(sessions_list: list[dict], token: Optional[str]) -> None:
    """Fetch each poster into the web dir so the token never reaches the browser."""
    keep = set()
    for s in sessions_list:
        key = s.get("art")
        if not key:
            continue
        name = "art-" + hashlib.md5(key.encode()).hexdigest()[:16] + ".jpg"
        path = WEB_DIR / name
        keep.add(name)
        if not path.is_file() and token:
            img = _api(key, token, as_json=False)
            if isinstance(img, (bytes, bytearray)) and len(img) > 200:
                write_bytes_atomic(path, bytes(img), mode=0o644)
        if path.is_file():
            s["thumb"] = name
    for old in WEB_DIR.glob("art-*.jpg"):
        if old.name not in keep:
            try:
                old.unlink()
            except OSError:
                pass


# ---- background activity -------------------------------------------------

def library_roots(token: Optional[str]) -> dict[str, str]:
    """Map a directory path to its library title, for labelling jobs."""
    roots = {}
    if not token:
        return roots
    j = _api("/library/sections", token)
    for d in (j or {}).get("MediaContainer", {}).get("Directory", []):
        title = d.get("title")
        for loc in d.get("Location", []):
            p = loc.get("path")
            if p and title:
                roots[p] = title
    return roots


def _classify(args: str, roots: dict[str, str]) -> Optional[dict]:
    low = args.lower()
    file = None
    m = re.search(r'-i\s+"?([^"]+?\.\w{2,4})"?(?:\s|$)', args)
    if m:
        file = m.group(1)
    library = None
    if file:
        for root, title in roots.items():
            if file.startswith(root):
                library = title
                break

    if "transcode/session/bif" in low or "indexes/bif" in low:
        kind, label, why = "bif", "Preview thumbnails", "generating scrub previews"
    elif "chapters" in low or "chapterimages" in low:
        kind, label, why = "chapter", "Chapter images", "extracting chapter thumbnails"
    elif "loudness" in low or "audio-analysis" in low:
        kind, label, why = "loudness", "Audio analysis", "measuring loudness"
    elif "transcode" in low:
        kind, label, why = "transcode", "Transcoding", "converting for a client"
    elif "eae" in low or "analysis" in low or "-analyze" in low:
        kind, label, why = "analysis", "Media analysis", "analysing a newly added file"
    elif "scanner" in low or "plex media scanner" in low:
        kind, label, why = "scan", "Library scan", "scanning for new media"
    else:
        return None

    return {"kind": kind, "label": label, "why": why,
            "file": Path(file).name if file else None,
            "dir": str(Path(file).parent) if file else None,
            "library": library}


def activity(roots: dict[str, str]) -> list[dict]:
    """What Plex is doing right now, from ps (reads /proc, no disk access)."""
    raw = run(["ps", "-eo", "etimes,pcpu,args", "--sort=-etimes"])
    jobs = []
    for line in raw.splitlines()[1:]:
        parts = line.strip().split(None, 2)
        if len(parts) < 3:
            continue
        etimes, pcpu, args = parts
        if "Plex Transcoder" not in args and "Plex Media Scanner" not in args \
                and "EasyAudioEncoder" not in args:
            continue
        job = _classify(args, roots)
        if not job:
            continue
        try:
            job["runtime_s"] = int(etimes)
            job["cpu"] = float(pcpu)
        except ValueError:
            job["runtime_s"] = 0
            job["cpu"] = 0.0
        jobs.append(job)
    return jobs


# ---- performance ---------------------------------------------------------

def perf(token: Optional[str]) -> dict:
    """Latency of a few key endpoints, plus DB size. No disk access."""
    out = {"direct": {}, "proxy": None, "db": {}}
    if token:
        # Same probe as the proxy side (one reused connection), so the two sets
        # of medians are measured identically and their difference is meaningful.
        u = urllib.parse.urlparse(PLEX_URL)
        out["direct"] = _probe_endpoints(u.hostname or "127.0.0.1",
                                         u.port or 32400,
                                         (u.scheme == "https"), token)

    # Same endpoints through the reverse proxy — the delta against the direct
    # figures is nginx's per-request cost. Fills perf.proxy.overhead_ms (the
    # "Reverse proxy" card) and the srv.pxy history line, like the PHP version.
    if token and PERF_PROXY_URL and out["direct"]:
        via = _proxy_probe(PERF_PROXY_URL, token)
        if via:
            deltas = [v["median_ms"] - out["direct"][p]["median_ms"]
                      for p, v in via.items() if p in out["direct"]]
            out["proxy"] = {
                "url": PERF_PROXY_URL,
                "endpoints": via,
                "overhead_ms": round(sum(deltas) / len(deltas), 2) if deltas else None,
            }
        else:
            out["proxy"] = {"url": PERF_PROXY_URL, "endpoints": {},
                            "overhead_ms": None, "error": "unreachable"}
    db = PLEX_PREFS.parent / "Plug-in Support" / "Databases" / \
        "com.plexapp.plugins.library.db"
    try:
        out["db"]["bytes"] = db.stat().st_size
        wal = db.with_name(db.name + "-wal")
        out["db"]["wal_bytes"] = wal.stat().st_size if wal.exists() else 0
    except OSError:
        pass
    # Free-page ratio via Plex's own SQLite build (reads the DB on the SSD, never
    # a media disk). A high ratio means the DB wants a VACUUM.
    plexsql = "/usr/lib/plexmediaserver/Plex SQLite"
    if os.path.isfile(plexsql) and db.exists():
        try:
            free = run([plexsql, str(db), "PRAGMA freelist_count;"], timeout=8).strip()
            page = run([plexsql, str(db), "PRAGMA page_count;"], timeout=8).strip()
            if free.isdigit() and page.isdigit() and int(page) > 0:
                out["db"]["free_pct"] = round(int(free) / int(page) * 100, 1)
        except Exception:
            pass
    # stale database copies Plex leaves behind after its own maintenance
    try:
        import glob as _glob
        bk = _glob.glob(str(db.parent / "com.plexapp.plugins.library.db-20*"))
        if bk:
            out["db"]["backup_count"] = len(bk)
            out["db"]["backup_bytes"] = sum(os.path.getsize(b) for b in bk
                                            if os.path.isfile(b))
    except OSError:
        pass
    return out


def _probe_endpoints(host: str, port: int, tls: bool, token: str) -> dict:
    """
    Median latency per endpoint over ONE reused connection — the method the PHP
    collector used and the page describes ("median over one reused connection").

    Reuse matters: opening a fresh connection per sample charges every request a
    TCP (and over TLS, a handshake) that has nothing to do with the server's
    work. Measuring the proxy that way made nginx look ~5 ms slower than it is,
    because the direct probe went to localhost unencrypted while the proxy probe
    paid a full TLS handshake each time. With one connection held open, only the
    first sample carries setup cost and the median lands among the clean ones.
    """
    import http.client
    try:
        if tls:
            import ssl
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            conn = http.client.HTTPSConnection(host, port, timeout=5, context=ctx)
        else:
            conn = http.client.HTTPConnection(host, port, timeout=5)
    except Exception:
        return {}

    out: dict = {}
    try:
        for ep in PERF_ENDPOINTS:
            sep = "&" if "?" in ep else "?"
            path = f"{ep}{sep}X-Plex-Token={urllib.parse.quote(token)}"
            samples = []
            size = 0
            for _ in range(PERF_SAMPLES):
                t0 = time.time()
                try:
                    conn.request("GET", path, headers={
                        "Accept": "application/json",
                        "Connection": "keep-alive",
                        "User-Agent": "plexmon/2.0",
                    })
                    resp = conn.getresponse()
                    body = resp.read()          # must drain to reuse the socket
                except Exception:
                    break
                samples.append((time.time() - t0) * 1000)
                size = len(body)
            if samples:
                samples.sort()
                out[ep] = {"median_ms": round(samples[len(samples) // 2], 2),
                           "bytes": size}
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return out


def _proxy_probe(base_url: str, token: str) -> dict:
    """Same endpoints through the reverse proxy, over one reused connection."""
    u = urllib.parse.urlparse(base_url)
    tls = (u.scheme or "https") == "https"
    host = u.hostname or ""
    port = u.port or (443 if tls else 80)
    if not host:
        return {}
    return _probe_endpoints(host, port, tls, token)


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


# ==========================================================================
# history
# ==========================================================================

def load() -> list[dict]:
    # Be strict about the shape: an old history.json from the PHP collector, or
    # any malformed file, could be a dict — and .append() on that would crash the
    # daemon. Anything that isn't a list of samples starts fresh.
    data = read_json(HISTORY_FILE, [])
    if not isinstance(data, list):
        return []
    return [s for s in data if isinstance(s, dict) and "t" in s]


def record(samples: list[dict], disks: list[dict], system: dict,
           perf: dict, plex: dict) -> list[dict]:
    """Append one sample and prune by age."""
    direct = perf.get("direct", {})
    sample = {
        "t": int(time.time()),
        "p": [
            direct.get("/identity", {}).get("median_ms"),
            direct.get("/library/sections", {}).get("median_ms"),
            direct.get("/hubs", {}).get("median_ms"),
        ],
        "s": [
            system.get("cpu_temp"),
            round(system.get("load", [0])[0], 2),
            (round(system["mem_used"] / system["mem_total"] * 100)
             if system.get("mem_total") else None),
        ],
        "x": [
            plex.get("sessions"),
            perf.get("db", {}).get("bytes"),
            perf.get("db", {}).get("wal_bytes"),
            perf.get("proxy", {}).get("overhead_ms") if perf.get("proxy") else None,
        ],
        "d": {},
    }
    for d in disks:
        key = d.get("hist_key") or d.get("serial") or d.get("dev")
        unit = 512000 if d.get("tran") == "nvme" else 512
        sample["d"][key] = [
            d.get("temp"),
            d.get("fs_pct"),
            d.get("fs_used_b"),
            # Only ever record counters we have just read from the drive. A
            # cached value is a real number but attached to the wrong moment: it
            # repeats unchanged while the disk sleeps, and then the next genuine
            # reading appears to jump by everything that accumulated meanwhile.
            # A rate computed across that pair blames hours of spin-ups on the
            # five minutes between two samples, which is where the absurd spikes
            # came from. Gaps while a disk sleeps are the honest answer: we did
            # not measure, so we do not claim.
            None if d.get("from_cache") else d.get("start_stop"),
            None if d.get("from_cache") else d.get("load_cycle"),
            None if d.get("from_cache") else (d.get("lba_written") or d.get("nvme_written")),
            None if d.get("from_cache") else (d.get("lba_read") or d.get("nvme_read")),
            None if d.get("from_cache") else d.get("crc_err"),
            None if d.get("from_cache") else (
                (d.get("realloc") or 0) + (d.get("pending") or 0)
                + (d.get("uncorrect") or 0) + (d.get("reported_unc") or 0)),
            unit,
        ]

    samples.append(sample)
    cutoff = time.time() - HISTORY_DAYS * 86400
    samples = [s for s in samples if s.get("t", 0) >= cutoff]
    if len(samples) > HISTORY_MAX:
        samples = samples[-HISTORY_MAX:]
    write_json(HISTORY_FILE, samples, mode=0o600)
    return samples


def series(samples: list[dict], disks: list[dict], points: int) -> dict:
    """Down-sample into the parallel arrays the page charts directly."""
    n = len(samples)
    if points and n > points:
        step = -(-n // points)  # ceil
        idx = list(range(0, n, step))
        if idx[-1] != n - 1:
            idx.append(n - 1)
        rows = [samples[i] for i in idx]
    else:
        rows = samples

    out = {
        "t": [s["t"] for s in rows],
        "perf": {"id": [], "ls": [], "hb": []},
        "sys": {"cpu": [], "load": [], "mem": []},
        "srv": {"sess": [], "db": [], "wal": [], "pxy": []},
        "disks": {},
    }
    for s in rows:
        out["perf"]["id"].append(s["p"][0])
        out["perf"]["ls"].append(s["p"][1])
        out["perf"]["hb"].append(s["p"][2])
        out["sys"]["cpu"].append(s["s"][0])
        out["sys"]["load"].append(s["s"][1])
        out["sys"]["mem"].append(s["s"][2])
        x = s.get("x", [None, None, None, None])
        out["srv"]["sess"].append(x[0])
        out["srv"]["db"].append(x[1])
        out["srv"]["wal"].append(x[2])
        out["srv"]["pxy"].append(x[3])

    labels = {}
    for d in disks:
        key = d.get("hist_key") or d.get("serial") or d.get("dev")
        labels[key] = {"label": d.get("mount") or d.get("dev"),
                       "dev": d.get("dev"), "tran": d.get("tran"),
                       "total_b": d.get("fs_size_b"),
                       "unit_b": 512000 if d.get("tran") == "nvme" else 512}
    for key, meta in labels.items():
        e = {**meta, "temp": [], "fs": [], "used": [], "ss": [], "lc": [],
             "lw": [], "lr": [], "crc": [], "errs": []}
        for s in rows:
            row = s.get("d", {}).get(key, [None] * 10)
            e["temp"].append(row[0]); e["fs"].append(row[1]); e["used"].append(row[2])
            e["ss"].append(row[3]); e["lc"].append(row[4]); e["lw"].append(row[5])
            e["lr"].append(row[6]); e["crc"].append(row[7]); e["errs"].append(row[8])
        out["disks"][key] = e
    return out


def spinups_window(samples: list[dict], key: str, seconds: int) -> Optional[int]:
    """
    Spin-ups within a trailing window, from the Start_Stop_Count history.

    Start_Stop_Count is only recorded on fresh SMART reads (a sleeping disk keeps
    its cached value out of the chart), so a window can easily contain no fresh
    reading at all. We therefore track the last known value at/before the window
    start and the last known value overall, and report their difference — which
    is 0 when the count hasn't moved, not "unknown". Only genuinely having no
    Start_Stop reading anywhere returns None.
    """
    cutoff = time.time() - seconds
    before = None          # last value at or before the window start
    win_first = None       # first value inside the window
    latest = None          # last value overall
    for s in samples:
        row = s.get("d", {}).get(key)
        if not row or len(row) < 4 or row[3] is None:
            continue
        v = int(row[3])
        latest = v
        if s.get("t", 0) <= cutoff:
            before = v
        elif win_first is None:
            win_first = v
    if latest is None:
        return None
    base = before if before is not None else win_first
    if base is None:
        base = latest
    d = latest - base
    return d if d >= 0 else None


# ==========================================================================
# diag
# ==========================================================================

import urllib.request
import urllib.error



G = "\033[32m"; Y = "\033[33m"; R = "\033[31m"; D = "\033[2m"; N = "\033[0m"


def _diag_api(path: str, timeout: float = 4.0):
    url = f"http://{API_HOST}:{API_PORT}{path}"
    t0 = time.time()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            body = r.read()
        return json.loads(body), (time.time() - t0) * 1000
    except Exception as e:
        return {"__error": str(e)}, (time.time() - t0) * 1000


def smart_age_note(d: dict) -> str:
    """
    How current a disk's SMART values are, for the CLI listings. Routine reads
    are throttled, so being served from cache is the normal state and says
    nothing about staleness — what matters is how old the numbers are.
    """
    age = d.get("cache_age")
    if d.get("smart_stale"):
        return f"  [SMART {age}s old]" if age else "  [SMART cached]"
    if d.get("from_cache") and age:
        return f"  [SMART {age}s ago]"
    return ""


def check() -> int:
    """Self-check: is every link in the chain working?"""
    ok = warn = bad = 0

    def p(status, name, detail=""):
        nonlocal ok, warn, bad
        col = {"ok": G, "warn": Y, "FAIL": R}[status]
        print(f"  {col}{status:5}{N} {name:32} {D}{detail}{N}")
        if status == "ok": ok += 1
        elif status == "warn": warn += 1
        else: bad += 1

    print(f"plexmon self-check   {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

    print("Daemon")
    health, ms = _diag_api("/health")
    if "__error" in health:
        p("FAIL", "API reachable", health["__error"])
        print(f"\n  {R}the daemon isn't answering — systemctl status plex-status{N}")
        return 1
    p("ok", "API reachable", f"{ms:.0f} ms, up {health.get('uptime', 0)}s")

    print("\nData")
    data, _ = _diag_api("/data.json")
    if "__error" in data:
        p("FAIL", "data.json", data["__error"])
    else:
        age = int(time.time()) - data.get("generated", 0)
        (p("ok", "snapshot fresh", f"{age}s old, status={data.get('overall')}")
         if age < 900 else p("warn", "snapshot stale", f"{age}s old"))
        n_re = len(data.get("reasons", []))
        if n_re:
            p("warn", "status reasons", str(n_re))
            for r in data.get("reasons", []):
                print(f"        {D}- [{r['level']}] {r['text']}{N}")
        else:
            p("ok", "no warnings", "all checks passed")
        for note in _CONFIG_NOTES:
            p("warn", "config file", note[:60])

        bad = [d.get("dev") for d in data.get("disks", [])
               if d.get("spindown_mismatch")]
        if bad:
            p("warn", "spindown assumption",
              f"{', '.join(bad)} spun up unnoticed — lower spindown_after_s")
        else:
            p("ok", "spindown assumption", f"{SPINDOWN_AFTER_S}s, no mismatch seen")

        lsr = data.get("last_smart_read", 0)
        if lsr:
            p("ok", "SMART read on record", f"{int(time.time()) - lsr}s ago")
        else:
            p("warn", "no SMART read yet", "waking a disk or the daily sweep will populate it")

    print("\nLive panels")
    tok = TOKEN_FILE
    if tok.is_file():
        wu = web_user()
        readable = False
        try:
            st = tok.stat()
            # group-readable and owned by the web user's group, or world-readable
            readable = bool(st.st_mode & 0o040) or bool(st.st_mode & 0o004)
        except OSError:
            pass
        p("ok" if readable else "warn", f"API token present",
          f"the page reads it as {wu}" if readable else "check group/permissions")
    else:
        p("warn", "no API token yet", "created when the daemon starts")

    sess, _ = _diag_api("/sessions")
    if "__error" not in sess:
        p("ok", "sessions endpoint", f"{len(sess.get('sessions', []))} stream(s)")

    print("\nWake button")
    disks = data.get("disks", []) if "__error" not in data else []
    probes = 0
    missing = []
    for d in disks:
        mp = d.get("mount")
        if mp and mp != "/" and d.get("tran") != "nvme":
            if (Path(mp) / ".wake-probe").is_file():
                probes += 1
            else:
                missing.append(mp)
    if probes and not missing:
        p("ok", "probe files", f"{probes} volume(s)")
    elif probes:
        p("warn", "probe files", "missing on: " + " ".join(missing))
    else:
        p("warn", "no probe files", "a wake request or the daily sweep creates them")

    print("\nDisks")
    for d in disks:
        if d.get("tran") == "nvme":
            continue
        temp = f"{d['temp']} C" if d.get("temp") is not None else "  -"
        cached = smart_age_note(d)
        print(f"        {d.get('dev'):8} {str(d.get('mount')):10} {temp:>6}{cached}"
              f"   spin-ups: {d.get('spinups_1h', '-')} / h, {d.get('spinups_24h', '-')} / 24h")

    print()
    if bad:
        print(f"{R}{bad} problem(s){N}, {warn} warning(s), {ok} ok")
        return 1
    if warn:
        print(f"{Y}{warn} warning(s){N}, {ok} ok — nothing broken")
        return 0
    print(f"{G}all {ok} checks passed{N}")
    return 0


def diag() -> int:
    """Latency-focused probe of the API and the disks' reported state."""
    print(f"plexmon diagnostics   {time.strftime('%H:%M:%S')}\n")
    for ep in ("/health", "/data.json", "/sessions", "/history-full.json", "/wakecheck"):
        res, ms = _diag_api(ep, timeout=6)
        status = f"{R}error{N}" if "__error" in res else f"{G}ok{N}"
        extra = res.get("__error", "") if "__error" in res else ""
        print(f"  {ep:22} {ms:7.1f} ms  {status}  {D}{extra}{N}")

    print(f"\n  effective settings (what is ACTUALLY in force):")
    print(f"    spindown_after_s      {SPINDOWN_AFTER_S}")
    print(f"    smart_min_interval    {SMART_MIN_INTERVAL}")
    print(f"    bridge_wakes_siblings {BRIDGE_WAKES_SIBLINGS}")
    print(f"    fast/slow interval    {FAST_INTERVAL}s / {SLOW_INTERVAL}s")
    for note in _CONFIG_NOTES:
        print(f"    {R}config: {note}{N}")

    data, _ = _diag_api("/data.json")
    if "__error" not in data:
        print("\n  disk power state (inferred, no disk access):")
        for d in data.get("disks", []):
            print(f"    {d.get('dev'):8} {d.get('power', '?'):8} "
                  f"{D}{d.get('power_src', '')}{N}"
                  + smart_age_note(d))
    return 0




# ==========================================================================
# apple tv remote
# ==========================================================================

# Playback control for Apple TV clients, driven through pyatv's `atvremote`.
#
# Plex itself cannot do this: its Apple TV app advertises no remote-control
# capability (`/clients` comes back empty), so the documented /player/ endpoints
# have nothing to talk to. pyatv instead speaks Apple's own Companion protocol
# and controls the *device*, whatever it happens to be playing.
#
# pyatv is deliberately NOT imported. It needs some seventy packages and cannot
# be installed into a distribution's system Python without fighting RPM, so it
# lives in its own virtualenv and is invoked as a command — exactly how this
# daemon already treats smartctl and lsblk. If that virtualenv is missing or
# broken, remote control simply reports itself unavailable and disk monitoring
# carries on untouched.

_ATV_CACHE: dict = {"at": 0.0, "devices": [], "running": False, "fails": 0}
_ATV_PAIRING: dict = {}          # identifier -> live pairing subprocess
_ATV_LOCK = threading.Lock()


def _find_atvremote() -> Optional[str]:
    """
    Locate pyatv's CLI. It may sit beside the interpreter running this daemon
    (the usual case when pyatv was installed for that specific Python), in a
    virtualenv, or simply on PATH.
    """
    if ATV_REMOTE:
        return ATV_REMOTE if os.access(ATV_REMOTE, os.X_OK) else None
    here = os.path.dirname(sys.executable)
    candidates = [os.path.join(here, "atvremote"),
                  "/usr/local/bin/atvremote", "/usr/bin/atvremote",
                  "/opt/atv/bin/atvremote"]
    found = shutil.which("atvremote")
    if found:
        candidates.append(found)
    for c in candidates:
        if c and os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def atv_ready() -> tuple:
    """(usable, reason) — why remote control is or isn't available."""
    if not ATV_ENABLE:
        return False, "turned off (set atv_enable in config.json)"
    if not _find_atvremote():
        return False, "atvremote not found — is pyatv installed for this Python?"
    return True, ""


def _atv_args(extra: list) -> list:
    return [_find_atvremote() or "atvremote", "--storage", "file",
            "--storage-filename", ATV_STORAGE] + extra


def _atv_run(extra: list, timeout: float = 30.0) -> tuple:
    """
    Run atvremote and return (ok, output).

    Success is the exit status, not the output. Playback commands print nothing
    when they work, and treating that silence as failure meant every successful
    pause was reported as "no response from the device" — while the television
    dutifully paused.
    """
    ok, why = atv_ready()
    if not ok:
        return False, why
    try:
        proc = subprocess.Popen(_atv_args(extra), stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True)
    except OSError as e:
        return False, str(e)
    try:
        out, _ = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        log(f"atvremote did not answer in {timeout}s — abandoning it")
        try:
            proc.kill()
        except OSError:
            pass
        threading.Thread(target=_reap, args=(proc,), daemon=True).start()
        return False, "the device did not answer in time"
    return proc.returncode == 0, (out or "").strip()


def _parse_scan(text: str) -> list:
    """
    Turn `atvremote scan` output into device records. The CLI has no machine
    readable mode, so this reads its human output — keep it forgiving.
    """
    devices, cur = [], None
    for raw in text.splitlines():
        line = raw.strip()
        m = re.match(r"^Name:\s*(.+)$", line)
        if m:
            cur = {"name": m.group(1).strip(), "model": None, "address": None,
                   "ident": None, "protocols": {}, "paired": False}
            devices.append(cur)
            continue
        if cur is None:
            continue
        m = re.match(r"^Model/SW:\s*(.+)$", line)
        if m:
            cur["model"] = m.group(1).strip()
            continue
        m = re.match(r"^Address:\s*(\S+)$", line)
        if m:
            cur["address"] = m.group(1)
            continue
        # the first identifier is the stable UUID; the others are MAC forms
        m = re.match(r"^-\s*([0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-"
                     r"[0-9A-F]{4}-[0-9A-F]{12})$", line, re.I)
        if m and not cur["ident"]:
            cur["ident"] = m.group(1)
            continue
        m = re.match(r"^-\s*Protocol:\s*(\w+),\s*Port:\s*(\d+),"
                     r"\s*Credentials:\s*([^,]+)", line)
        if m:
            proto, port, creds = m.group(1), int(m.group(2)), m.group(3).strip()
            have = creds.lower() not in ("none", "")
            cur["protocols"][proto] = {"port": port, "paired": have}
            if proto == "Companion" and have:
                cur["paired"] = True
    return [d for d in devices if d.get("ident")]


def atv_scan(force: bool = False, max_age: float = 300.0) -> list:
    """
    Discover Apple TVs. BLOCKS for up to forty seconds, so it belongs only in
    paths where the caller expects to wait — an explicit rescan or a pairing
    step. Everything else must go through atv_devices().
    """
    with _ATV_LOCK:
        fresh = time.time() - _ATV_CACHE["at"] < max_age
        if _ATV_CACHE["devices"] and fresh and not force:
            return _ATV_CACHE["devices"]
    # Only the protocol we actually use. A full scan probes several and takes
    # correspondingly longer — and this runs inside the service's CPU quota,
    # where everything is several times slower than on a shell.
    ok, out = _atv_run(["--scan-protocols", "companion", "scan"], timeout=45)
    devices = _parse_scan(out) if ok else []
    with _ATV_LOCK:
        # keep the previous list on a failed scan rather than forgetting devices
        if devices or not _ATV_CACHE["devices"]:
            _ATV_CACHE["devices"] = devices
        if devices:
            _ATV_CACHE["fails"] = 0
        else:
            # Back off after a failure instead of retrying on every cycle. A scan
            # that cannot work — no route to the devices, a wedged helper — would
            # otherwise fill the log and burn the service's CPU budget forever.
            _ATV_CACHE["fails"] = _ATV_CACHE.get("fails", 0) + 1
            if _ATV_CACHE["fails"] in (1, 5, 20):
                log(f"no Apple TV found ({_ATV_CACHE['fails']} attempts); "
                    f"backing off")
        _ATV_CACHE["at"] = time.time()
        _ATV_CACHE["running"] = False
        return _ATV_CACHE["devices"]


def atv_devices() -> list:
    """
    The known devices, without ever waiting. A network scan takes tens of
    seconds; doing it inline once blocked the very request the page uses to draw
    Now Playing, so the panel came up empty. Here a stale list triggers a
    refresh in the background and the caller gets whatever is known right now —
    at worst an empty list, which only means the buttons appear a scan later.
    """
    ok, _ = atv_ready()
    if not ok:
        return []
    with _ATV_LOCK:
        devices = _ATV_CACHE["devices"]
        # five minutes normally, up to an hour once scans keep failing
        wait = min(300 * (1 + _ATV_CACHE.get("fails", 0)), 3600)
        stale = time.time() - _ATV_CACHE["at"] > wait
        busy = _ATV_CACHE.get("running")
        if stale and not busy:
            _ATV_CACHE["running"] = True
            threading.Thread(target=atv_scan, kwargs={"force": True},
                             daemon=True).start()
    return devices


def atv_for_address(addr: str) -> Optional[dict]:
    """The Apple TV at this address, which is how a Plex session is matched."""
    if not addr:
        return None
    for d in atv_devices():
        if d.get("address") == addr:
            return d
    return None




# ---- live connections ----------------------------------------------------
#
# Spawning `atvremote` per keypress costs four to five seconds, nearly all of it
# spent negotiating a fresh encrypted session with the television. A pause
# button that answers in five seconds is not a pause button, so commands go
# through a connection that is opened once and kept.
#
# That needs pyatv in-process. It is imported lazily and behind a guard: if the
# library is missing or fails to load, remote control switches itself off and
# the disk monitoring this daemon exists for is untouched. Everything runs on
# one asyncio loop in a background thread, because pyatv is async and the rest
# of this daemon is threads.

_ATV_LOOP = None                 # asyncio loop owned by the helper thread
_ATV_CONN: dict = {}             # identifier -> connected AppleTV interface
_ATV_STORE = None                # pyatv credential storage, loaded once
_ATV_IMPORT_FAILED = False


def _atv_lib():
    """Import pyatv on first use; None if it isn't usable."""
    global _ATV_IMPORT_FAILED
    if _ATV_IMPORT_FAILED:
        return None
    try:
        import pyatv                                   # noqa: F401
        import pyatv.storage.file_storage               # noqa: F401
        return pyatv
    except Exception as e:                             # pragma: no cover
        _ATV_IMPORT_FAILED = True
        log(f"pyatv unavailable ({e}) — remote control disabled")
        return None


def _atv_get_loop():
    """The background asyncio loop, started on first use."""
    global _ATV_LOOP
    if _ATV_LOOP is None:
        import asyncio
        loop = asyncio.new_event_loop()
        t = threading.Thread(target=loop.run_forever, daemon=True,
                             name="plexmon-atv")
        t.start()
        _ATV_LOOP = loop
    return _ATV_LOOP


def _atv_submit(coro, timeout: float = 12.0):
    """Run a coroutine on the helper loop and wait for it from a thread."""
    import asyncio
    fut = asyncio.run_coroutine_threadsafe(coro, _atv_get_loop())
    return fut.result(timeout=timeout)


async def _atv_storage():
    """Credential store, loaded once and shared."""
    global _ATV_STORE
    if _ATV_STORE is None:
        import asyncio
        from pyatv.storage.file_storage import FileStorage
        st = FileStorage(ATV_STORAGE, asyncio.get_running_loop())
        await st.load()
        _ATV_STORE = st
    return _ATV_STORE


async def _atv_connect(ident: str, address: Optional[str]):
    """Open a session to one device, or reuse the one already open."""
    import asyncio
    import pyatv
    existing = _ATV_CONN.get(ident)
    if existing is not None:
        return existing
    loop = asyncio.get_running_loop()
    store = await _atv_storage()
    confs = await pyatv.scan(loop, identifier=ident, timeout=5,
                             hosts=[address] if address else None, storage=store)
    if not confs:
        raise RuntimeError("device not found on the network")
    atv = await pyatv.connect(confs[0], loop, storage=store)
    _ATV_CONN[ident] = atv
    log(f"connected to Apple TV {ident}", level="debug")
    return atv


async def _atv_drop(ident: str) -> None:
    """Close a session, e.g. after an error, so the next try reconnects."""
    atv = _ATV_CONN.pop(ident, None)
    if atv is None:
        return
    try:
        atv.close()
    except Exception:
        pass


async def _atv_do(ident: str, address: Optional[str], cmd: str) -> None:
    """
    Send one command, reconnecting once if the held session has gone stale —
    a television that slept or changed address drops it silently.
    """
    for attempt in (1, 2):
        atv = await _atv_connect(ident, address)
        try:
            await getattr(atv.remote_control, cmd)()
            return
        except Exception:
            await _atv_drop(ident)
            if attempt == 2:
                raise


def atv_warm(ident: str, address: Optional[str]) -> None:
    """
    Make sure a session to this device is open, without waiting for it.

    Even the library import is left to the background thread: it costs the best
    part of a second the first time, and this is called from the collection and
    from the request that draws Now Playing — neither should stall for it.
    """
    if ident in _ATV_CONN or _ATV_IMPORT_FAILED:
        return
    def go():
        if not _atv_lib():
            return
        try:
            _atv_submit(_atv_connect(ident, address), timeout=20)
        except Exception as e:
            log(f"could not open a session to {ident}: {e}", level="debug")
    threading.Thread(target=go, daemon=True).start()


def atv_command(ident: str, cmd: str) -> tuple:
    """
    Send one playback command. `skip_forward` / `skip_backward` use the app's
    own step (ten seconds in Plex), so there's no need to compute a position.
    """
    allowed = {"play", "pause", "play_pause", "stop",
               "skip_forward", "skip_backward", "next", "previous"}
    if cmd not in allowed:
        return False, f"unknown command '{cmd}'"
    dev = next((d for d in atv_devices() if d.get("ident") == ident), None)
    address = dev.get("address") if dev else None

    # Preferred path: a session that is already open, so the command is one
    # message on the wire rather than a fresh handshake.
    live_err = None
    if _atv_lib():
        try:
            _atv_submit(_atv_do(ident, address, cmd), timeout=8)
            return True, ""
        except Exception as e:
            live_err = str(e) or e.__class__.__name__
            # Visible in the journal, not hidden behind debug: when the buttons
            # stop working this is the line that says why.
            log(f"Apple TV {cmd} over the open session failed: {live_err}")

    # Fallback: the CLI. Kept short — stacking a long retry behind the first
    # attempt only means the browser gives up before either finishes and reports
    # a failure that never happened.
    args = ["--id", ident]
    if address:
        args += ["--scan-hosts", address]
    ok, out = _atv_run(args + [cmd], timeout=15)
    if ok:
        return True, out
    detail = _atv_safe_message(out)
    if not detail and live_err:
        detail = live_err[:160]
    if detail:
        log(f"Apple TV {cmd} failed: {detail}")
    return False, detail or "the device did not respond"


def atv_unpair(ident: str) -> tuple:
    """
    Forget the credentials we hold for a device.

    pyatv has no unpair command, so the stored credential is removed from its
    settings file directly. Note what this does and does not do: it revokes our
    ability to control the television, but the television still lists this
    server among its paired remotes. Removing it there is done in tvOS settings.
    """
    ok, why = atv_ready()
    if not ok:
        return False, why
    data = read_json(Path(ATV_STORAGE), None)
    if not isinstance(data, dict) or not isinstance(data.get("devices"), list):
        return False, "no pairing store to change"
    hit = False
    for dev in data["devices"]:
        protos = (dev or {}).get("protocols") or {}
        for name, proto in protos.items():
            if not isinstance(proto, dict):
                continue
            if str(proto.get("identifier", "")).upper() == ident.upper() \
                    or name == "companion" and str(
                        protos.get("companion", {}).get("identifier", "")).upper() == ident.upper():
                if proto.pop("credentials", None) is not None:
                    hit = True
    if not hit:
        return False, "that device is not paired here"
    if not write_json(Path(ATV_STORAGE), data, mode=0o600):
        return False, "could not write the pairing store"
    log(f"forgot Apple TV credentials for {ident}")
    _atv_forget(ident)
    return True, "unpaired"


def _atv_forget(ident: Optional[str]) -> None:
    """
    Clean up after removing credentials from the file.

    Two things would otherwise undo it. The loaded credential store still holds
    the old secrets in memory and would write them back on its next save, and
    the cached device list still says "paired", so the page would keep drawing
    the controls until a fresh network scan happened to run. Both are dropped
    here, and the cached list is corrected immediately rather than waiting the
    several seconds a scan takes.
    """
    global _ATV_STORE
    for k in ([ident] if ident else list(_ATV_CONN)):
        if _atv_lib() and k in _ATV_CONN:
            try:
                _atv_submit(_atv_drop(k), timeout=5)
            except Exception:
                pass
    _ATV_STORE = None
    with _ATV_LOCK:
        for d in _ATV_CACHE["devices"]:
            if ident is None or d.get("ident") == ident:
                d["paired"] = False
                for proto in d.get("protocols", {}).values():
                    proto["paired"] = False


def atv_unpair_all() -> tuple:
    """Forget every stored credential, leaving the devices themselves listed."""
    ok, why = atv_ready()
    if not ok:
        return False, why
    data = read_json(Path(ATV_STORAGE), None)
    if not isinstance(data, dict) or not isinstance(data.get("devices"), list):
        return False, "no pairing store to change"
    gone = 0
    for dev in data["devices"]:
        for proto in ((dev or {}).get("protocols") or {}).values():
            if isinstance(proto, dict) and proto.pop("credentials", None) is not None:
                gone += 1
    if not gone:
        return True, "nothing was paired"
    if not write_json(Path(ATV_STORAGE), data, mode=0o600):
        return False, "could not write the pairing store"
    log(f"forgot Apple TV credentials for {gone} device(s)")
    _atv_forget(None)
    return True, f"forgot {gone} credential(s)"


def atv_pair_start(ident: str) -> tuple:
    """
    Begin pairing. The Apple TV puts a PIN on screen and atvremote waits for it
    on stdin, so the process is kept alive until the PIN arrives from the page.
    """
    ok, why = atv_ready()
    if not ok:
        return False, why
    with _ATV_LOCK:
        old = _ATV_PAIRING.pop(ident, None)
    if old:
        try:
            old.kill()
        except Exception:
            pass
    try:
        proc = subprocess.Popen(
            _atv_args(["--id", ident, "--protocol", "companion", "pair"]),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True)
    except OSError as e:
        return False, str(e)
    with _ATV_LOCK:
        _ATV_PAIRING[ident] = proc
    # give the device a moment to show its PIN, and catch an immediate failure
    time.sleep(2.0)
    if proc.poll() is not None:
        out = (proc.stdout.read() if proc.stdout else "") or "pairing ended early"
        with _ATV_LOCK:
            _ATV_PAIRING.pop(ident, None)
        return False, _atv_safe_message(out) or "pairing ended early"
    return True, "PIN should now be on the TV"


def atv_pair_pin(ident: str, pin: str) -> tuple:
    """Finish pairing by feeding the PIN shown on the television."""
    if not re.fullmatch(r"\d{4,8}", pin or ""):
        return False, "the PIN is four to eight digits"
    with _ATV_LOCK:
        proc = _ATV_PAIRING.pop(ident, None)
    if proc is None:
        return False, "no pairing in progress — start it again"
    try:
        out, _ = proc.communicate(input=pin + "\n", timeout=TV_PAIR_TIMEOUT)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
        except Exception:
            pass
        return False, "the device did not finish pairing in time"
    out = (out or "").strip()
    # pyatv announces success with "Pairing seems to have succeeded, yey!" and
    # then prints the credentials. Matching on the word "success" missed it —
    # the text says "succeeded" — so a perfectly good pairing was reported as an
    # error, with the credentials themselves shown as the error message.
    failed = re.search(r"pairing failed", out, re.I)
    good = re.search(r"succeeded|you may now use these credentials", out, re.I)
    if good and not failed:
        atv_scan(force=True)          # pick up the stored credentials
        return True, "paired"
    return False, _atv_safe_message(out) or "pairing failed"


def _atv_safe_message(out: str) -> str:
    """
    A line worth showing a user, with secrets removed. The pairing credentials
    are a long hex string that grants control of the television — they belong in
    the credential file, never on a web page or in a log.
    """
    lines = [l.strip() for l in (out or "").splitlines() if l.strip()]
    keep = [l for l in lines if "credential" not in l.lower()]
    text = (keep[-1] if keep else "")[:200]
    return re.sub(r"[0-9a-f:]{40,}", "…", text, flags=re.I)




# ==========================================================================
# lg and samsung televisions
# ==========================================================================

# The same idea as the Apple TV support, for the other two makes worth having.
# Discovery is deliberately not a network sweep: Plex already tells us which
# address a stream is playing to, and that is the only television we care
# about, so the address is simply probed.
#
#   Samsung  http://<ip>:8001/api/v2/   answers with device info
#   LG       a WebSocket listening on port 3000
#
# Neither library is imported unless a television of that make is actually
# found, and a failed import only disables that make.

TV_CREDS = "/var/lib/plex-status/tv-creds.json"

# How long to wait for someone to walk over and accept the prompt on the
# television. Ten seconds was the socket default and nowhere near enough — the
# set asks, and by the time the remote is in hand the connection has gone.
TV_PAIR_TIMEOUT = 90

# Which remote-control key each button maps to on a Samsung. There is no media
# API there — only the codes the physical remote sends — so the television's
# foreground app decides what they mean. These match a modern Samsung remote:
# a dedicated play/pause key, and left/right for stepping through playback.
# A value may be one key or a list of them sent in order.
#
# One key by default, because two is unpredictable: whether an arrow seeks or
# merely wakes the playback bar depends on whether that bar is already showing,
# so a double press skipped ten seconds, twenty, or nothing at all depending on
# what the screen happened to be doing. Predictable beats clever. Use a sequence
# only if your set genuinely needs waking first — and see `--atv-key` for
# finding out which code it listens to.
TV_SAMSUNG_KEYS = {
    "play_pause": "KEY_PLAY_BACK",
    "skip_forward": "KEY_FF",
    "skip_backward": "KEY_REWIND",
}

# Between the keys of a sequence, so the set has time to react to the first.
TV_SAMSUNG_KEY_DELAY = 0.4

_TV_PROBED: dict = {}            # address -> kind or None, so we probe once
_TV_CONN: dict = {}              # address -> live LG client
_TV_LOCK = threading.Lock()
_TV_IMPORT_FAILED: dict = {"lg": False, "samsung": False}


def _tv_load() -> dict:
    """Stored pairings, keyed by address: {kind, name, key}."""
    data = read_json(Path(TV_CREDS), {})
    return data if isinstance(data, dict) else {}


def _tv_save(data: dict) -> bool:
    return write_json(Path(TV_CREDS), data, mode=0o600)


def _tv_lib(kind: str):
    """Import a make's library on first use; None if it isn't usable."""
    if _TV_IMPORT_FAILED.get(kind):
        return None
    try:
        if kind == "samsung":
            import samsungtvws
            return samsungtvws
        if kind == "lg":
            import aiowebostv
            return aiowebostv
    except Exception as e:
        _TV_IMPORT_FAILED[kind] = True
        log(f"{kind} library unavailable ({e}) — that make is disabled")
    return None


def tv_probe(address: str) -> Optional[str]:
    """
    Which make, if any, answers at this address. Cached: a television that is
    not a Samsung will not become one, and probing on every poll would put a
    pointless connection attempt on the network every few seconds.
    """
    if not address:
        return None
    with _TV_LOCK:
        if address in _TV_PROBED:
            return _TV_PROBED[address]
    kind = None
    # Samsung answers a plain HTTP request with its device description.
    try:
        req = urllib.request.Request(f"http://{address}:8001/api/v2/")
        with urllib.request.urlopen(req, timeout=2.0) as r:
            info = json.loads(r.read().decode())
        if isinstance(info, dict) and info.get("device"):
            kind = "samsung"
    except Exception:
        pass
    # LG has no such endpoint; the open WebSocket port is the giveaway.
    if kind is None:
        for port in (3000, 3001):
            try:
                with socket.create_connection((address, port), timeout=1.5):
                    kind = "lg"
                    break
            except OSError:
                continue
    with _TV_LOCK:
        _TV_PROBED[address] = kind
    if kind:
        log(f"found a {kind} television at {address}")
    return kind


def tv_name(address: str, kind: str) -> str:
    """A friendly name, asked of the television itself where that is cheap."""
    if kind == "samsung":
        try:
            req = urllib.request.Request(f"http://{address}:8001/api/v2/")
            with urllib.request.urlopen(req, timeout=2.0) as r:
                info = json.loads(r.read().decode())
            dev = info.get("device") or {}
            return dev.get("name") or dev.get("modelName") or f"Samsung {address}"
        except Exception:
            return f"Samsung {address}"
    return f"LG {address}"


def tv_for_address(address: str) -> Optional[dict]:
    """The television at this address: stored pairing, or a fresh probe."""
    if not address:
        return None
    stored = _tv_load().get(address)
    if stored:
        return {"kind": stored.get("kind"), "address": address,
                "name": stored.get("name") or address,
                "paired": bool(stored.get("key") or stored.get("kind") == "samsung_open")}
    kind = tv_probe(address)
    if not kind:
        return None
    return {"kind": kind, "address": address,
            "name": tv_name(address, kind), "paired": False}


# ---- Samsung -------------------------------------------------------------
# The library is synchronous, so its calls run on a worker thread rather than
# on the asyncio loop the other backends share.

# Sets differ in which chatter they emit right after a WebSocket opens, and the
# library only tolerates two such messages before deciding the connection has
# failed. A Q60, for one, announces `ms.remote.touchDisable` first and the
# handshake was rejected over a message that means nothing to us. These are all
# harmless notifications, so they are added to the list the library skips past
# while waiting for the real "connected" event.
_SAMSUNG_EXTRA_STARTUP_EVENTS = (
    "ms.remote.touchDisable", "ms.remote.touchEnable",
    "ms.channel.ready", "ms.channel.clientConnect",
    "ms.remote.imeStart", "ms.remote.imeEnd",
)


def _samsung_patch_startup() -> None:
    try:
        import samsungtvws.connection as conn
    except Exception:
        return
    current = tuple(getattr(conn, "IGNORE_EVENTS_AT_STARTUP", ()))
    missing = tuple(e for e in _SAMSUNG_EXTRA_STARTUP_EVENTS if e not in current)
    if missing:
        conn.IGNORE_EVENTS_AT_STARTUP = current + missing


def _samsung_client(address: str, token: Optional[str], token_file: Optional[str] = None,
                    timeout: float = 10.0):
    lib = _tv_lib("samsung")
    if lib is None:
        raise RuntimeError("samsungtvws is not installed")
    _samsung_patch_startup()
    from samsungtvws import SamsungTVWS
    # Port 8002 is the encrypted, token-authenticated channel modern sets use;
    # 8001 is the older plain one. Try the modern one first.
    last = None
    for port in (8002, 8001):
        try:
            tv = SamsungTVWS(host=address, port=port, token=token,
                             token_file=token_file, timeout=timeout, name="plexmon")
            tv.open()          # the handshake happens here, so failures surface now
            return tv
        except Exception as e:
            last = e
    raise RuntimeError(str(last) if last else "could not reach the television")


def _samsung_command(address: str, cmd: str, token: Optional[str]) -> tuple:
    keys = TV_SAMSUNG_KEYS.get(cmd)
    if not keys:
        return False, f"{cmd} is not mapped to a key on Samsung"
    if isinstance(keys, str):
        keys = [keys]
    tv = _samsung_client(address, token)      # tolerates the startup chatter too
    try:
        for i, key in enumerate(keys):
            if i:
                time.sleep(TV_SAMSUNG_KEY_DELAY)
            tv.send_key(key)
    finally:
        try:
            tv.close()
        except Exception:
            pass
    return True, ""


def samsung_send_key(address: str, key: str) -> tuple:
    """
    Send one raw key, for working out which code a set actually listens to.
    Which key does what is a matter of the app on screen, not of any standard,
    so this exists to be tried rather than guessed at.
    """
    rec = _tv_load().get(address)
    if not rec or rec.get("kind") != "samsung":
        return False, "that address is not a paired Samsung"
    if not re.fullmatch(r"KEY_[A-Z0-9_]+", key or ""):
        return False, "keys look like KEY_PLAY or KEY_FF"
    box: list = []
    def go():
        try:
            tv = _samsung_client(address, rec.get("key"))
            tv.send_key(key)
            try:
                tv.close()
            except Exception:
                pass
            box.append((True, ""))
        except Exception as e:
            box.append((False, str(e) or e.__class__.__name__))
    t = threading.Thread(target=go, daemon=True)
    t.start()
    t.join(timeout=20)
    return box[0] if box else (False, "the television did not answer")


def _samsung_pair(address: str) -> tuple:
    """
    Ask the television for permission. Opening the connection is enough to make
    it show its prompt — no key needs sending, and sending one would have been
    actively rude: an earlier version pressed Home, which would jump the set away
    from whatever was playing. Accepting the prompt hands back a token, which the
    library writes to the token file for us.

    Two attempts, because the first connection is what raises the prompt and the
    set usually closes it while the viewer is still reaching for the remote; by
    the second the answer is known.
    """
    tmp = str(Path(TV_CREDS).with_name(f".samsung-{address}.token"))
    last = None
    for attempt in (1, 2):
        try:
            # The socket has to stay open while the prompt is on screen.
            tv = _samsung_client(address, None, token_file=tmp,
                                 timeout=TV_PAIR_TIMEOUT)
            token = getattr(tv, "token", None)
            try:
                tv.close()
            except Exception:
                pass
            if not token:
                try:
                    token = Path(tmp).read_text().strip()
                except OSError:
                    token = None
            if token:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                return token
            last = "no token returned"
        except Exception as e:
            last = str(e) or e.__class__.__name__
        if attempt == 1:
            time.sleep(3)
    raise RuntimeError(f"the television refused: {last} — was the prompt accepted?")


# ---- LG ------------------------------------------------------------------
# Async, so it shares the asyncio loop already running for the Apple TV work,
# and its connection is kept open for the same reason: speed.

async def _lg_client(address: str, key: Optional[str]):
    existing = _TV_CONN.get(address)
    if existing is not None:
        return existing
    if _tv_lib("lg") is None:
        raise RuntimeError("aiowebostv is not installed")
    from aiowebostv import WebOsClient
    client = WebOsClient(address, client_key=key)
    await client.connect()
    _TV_CONN[address] = client
    return client


async def _lg_drop(address: str) -> None:
    client = _TV_CONN.pop(address, None)
    if client is None:
        return
    try:
        await client.disconnect()
    except Exception:
        pass


async def _lg_do(address: str, key: Optional[str], cmd: str,
                 playing: bool) -> None:
    """
    LG exposes proper media controls rather than key presses, but no play/pause
    toggle — so the current state, which Plex already reports, decides which of
    the two to send.
    """
    for attempt in (1, 2):
        client = await _lg_client(address, key)
        try:
            if cmd == "play_pause":
                await (client.pause() if playing else client.play())
            elif cmd == "skip_forward":
                await client.button("RIGHT")
            elif cmd == "skip_backward":
                await client.button("LEFT")
            else:
                raise RuntimeError(f"unknown command {cmd}")
            return
        except Exception:
            await _lg_drop(address)
            if attempt == 2:
                raise


async def _lg_pair(address: str) -> str:
    """Connecting without a key makes the television ask; accepting returns one."""
    if _tv_lib("lg") is None:
        raise RuntimeError("aiowebostv is not installed")
    from aiowebostv import WebOsClient
    client = WebOsClient(address, client_key=None,
                         connect_timeout=float(TV_PAIR_TIMEOUT))
    await client.connect()
    key = getattr(client, "client_key", None)
    try:
        await client.disconnect()
    except Exception:
        pass
    if not key:
        raise RuntimeError("no key returned — was the prompt accepted?")
    return key


# ---- shared entry points -------------------------------------------------

def tv_command(address: str, cmd: str, playing: bool = True) -> tuple:
    """Send a playback command to an LG or Samsung television."""
    rec = _tv_load().get(address)
    if not rec:
        return False, "that television is not paired"
    kind = rec.get("kind")
    try:
        if kind == "samsung":
            fut: list = []
            def go():
                try:
                    fut.append(_samsung_command(address, cmd, rec.get("key")))
                except Exception as e:
                    fut.append((False, str(e)))
            t = threading.Thread(target=go, daemon=True)
            t.start()
            t.join(timeout=12)
            if not fut:
                return False, "the television did not answer in time"
            return fut[0]
        if kind == "lg":
            _atv_submit(_lg_do(address, rec.get("key"), cmd, playing), timeout=10)
            return True, ""
    except Exception as e:
        msg = str(e) or e.__class__.__name__
        log(f"{kind} command {cmd} to {address} failed: {msg}")
        return False, msg[:160]
    return False, f"unknown television type {kind!r}"


def tv_pair(address: str) -> tuple:
    """
    Pair with an LG or Samsung. Both show a prompt that must be accepted with
    the physical remote — there is no code to type, so unlike the Apple TV this
    is a single step.
    """
    kind = tv_probe(address)
    if not kind:
        return False, "no LG or Samsung television answers at that address"
    try:
        if kind == "samsung":
            box: list = []
            def go():
                try:
                    box.append(("ok", _samsung_pair(address)))
                except Exception as e:
                    box.append(("err", str(e)))
            t = threading.Thread(target=go, daemon=True)
            t.start()
            t.join(timeout=TV_PAIR_TIMEOUT * 2 + 10)
            if not box:
                return False, "timed out waiting for the television"
            tag, val = box[0]
            if tag == "err":
                return False, val[:160]
            key = val
        else:
            key = _atv_submit(_lg_pair(address), timeout=TV_PAIR_TIMEOUT)
    except Exception as e:
        return False, (str(e) or e.__class__.__name__)[:160]
    data = _tv_load()
    data[address] = {"kind": kind, "name": tv_name(address, kind), "key": key}
    if not _tv_save(data):
        return False, "could not save the pairing"
    log(f"paired with the {kind} television at {address}")
    return True, "paired"


def tv_unpair(address: str) -> tuple:
    """Forget one television, and close any session held to it."""
    data = _tv_load()
    if address not in data:
        return False, "that television is not paired here"
    kind = data[address].get("kind")
    del data[address]
    if not _tv_save(data):
        return False, "could not write the pairing store"
    if kind == "lg" and address in _TV_CONN:
        try:
            _atv_submit(_lg_drop(address), timeout=5)
        except Exception:
            pass
    log(f"forgot the {kind} television at {address}")
    return True, "unpaired"


def tv_unpair_all() -> tuple:
    data = _tv_load()
    if not data:
        return True, "nothing was paired"
    n = len(data)
    for address in list(data):
        if data[address].get("kind") == "lg" and address in _TV_CONN:
            try:
                _atv_submit(_lg_drop(address), timeout=5)
            except Exception:
                pass
    if not _tv_save({}):
        return False, "could not write the pairing store"
    log(f"forgot {n} television(s)")
    return True, f"forgot {n} television(s)"


# ==========================================================================
# daemon
# ==========================================================================



class Daemon:
    def __init__(self) -> None:
        self.mon = DiskMonitor()
        self.lock = threading.Lock()          # guards only the published snapshot
        self.tick_lock = threading.Lock()     # serializes collections (fast loop vs wake)
        self.snapshot: dict = {}
        self.token = self._ensure_token()
        self._wake_deadline = 0.0             # forced-SMART requested until this time
        self._spinning_up = False             # a wake is currently spinning disks up
        self._wake_passes = 0                 # forced passes made in this wake window
        self._tick_started = 0.0              # when the running collection began
        self._stall_logged = 0.0              # last time a stall was reported
        self._last_slow = 0.0
        self._last_daily = 0.0
        self._plex_token = None
        self._roots: dict = {}
        self._roots_at = 0.0

    # -- API token: written where only the web user can read it -------------
    def _ensure_token(self) -> str:
        existing = None
        try:
            existing = TOKEN_FILE.read_text().strip()
        except OSError:
            pass
        tok = existing or secrets.token_urlsafe(32)
        RUN_DIR.mkdir(parents=True, exist_ok=True)
        try:
            TOKEN_FILE.write_text(tok)
            TOKEN_FILE.chmod(0o640)
            wu = web_user()
            uid = uid_of(wu)
            if uid is not None:
                try:
                    os.chown(TOKEN_FILE, 0, os.stat(TOKEN_FILE).st_gid)
                    # group-owned by the web user's group so 0640 lets it read
                    try:
                        gid = grp.getgrnam(wu).gr_gid
                        os.chown(TOKEN_FILE, 0, gid)
                    except KeyError:
                        os.chown(TOKEN_FILE, 0, uid)
                except PermissionError:
                    pass
            log(f"API token ready for the web page (readable by {wu})")
        except OSError as e:
            log(f"could not write token file: {e}")
        return tok

    # -- Plex token, refreshed occasionally --------------------------------
    def _get_plex_token(self) -> str | None:
        if self._plex_token is None:
            self._plex_token = plex_token()
        return self._plex_token

    def _get_roots(self, tok) -> dict:
        if time.time() - self._roots_at > 3600:
            self._roots = library_roots(tok)
            self._roots_at = time.time()
        return self._roots

    # ---- the loops -------------------------------------------------------
    def monitor_state(self) -> dict:
        """What the dashboard says, in short - for Settings' header."""
        with self.lock:
            snap = self.snapshot or {}
        plex = snap.get("plex") or {}
        return {"overall": snap.get("overall"), "generated": snap.get("generated"),
                "disks": len(snap.get("disks") or []),
                "reasons": [r.get("text") for r in (snap.get("reasons") or [])][:6],
                "plex": {"active": plex.get("active"), "version": plex.get("version"),
                         "sessions": plex.get("sessions")},
                # For Settings' performance meter (2.7.1): which disk sleeps, and
                # the temperature its last SMART read gave - nothing read anew.
                "disk_state": [{"dev": d.get("dev"), "power": d.get("power"),
                                "temp": d.get("temp")}
                               for d in (snap.get("disks") or []) if isinstance(d, dict)]}

    def _start_admin(self) -> None:
        """Settings (plexmon_admin.py): its own API and threads. A Settings
        that will not start never stops the dashboard."""
        try:
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            import plexmon_admin
            self.admin = plexmon_admin.start(monitor=self.monitor_state)
        except Exception as e:                          # noqa: BLE001
            import traceback
            log(f"Settings did not start: {e}\n{traceback.format_exc()}")
            self.admin = None

    def run(self) -> None:
        api = threading.Thread(target=self._serve_api, daemon=True)
        api.start()
        self._start_admin()
        for note in _CONFIG_NOTES:
            log(f"config: {note}")
        log(f"plexmon started; API on http://{API_HOST}:{API_PORT}")
        # prime a snapshot immediately so the page isn't empty on first load
        self._tick(force_smart=False)
        while True:
            start = time.time()
            try:
                self._tick(force_smart=False)
            except Exception as e:
                log(f"tick error: {e}")
            elapsed = time.time() - start
            time.sleep(max(1.0, FAST_INTERVAL - elapsed))

    def _tick(self, *, force_smart: bool, wait: bool = False,
              refresh: bool = False) -> None:
        # Only one collection at a time. The fast loop and a wake-triggered tick
        # both call this; running two smartctl sweeps at once would race on the
        # cache. A routine tick skips if one is already running (the running one
        # will publish fresh data anyway); a forced tick, or one explicitly asked
        # to wait, blocks for its turn. `wait` exists for the wake's status
        # publish: it reads no SMART, so it's cheap, but it must not be dropped
        # or the dashboard keeps showing the pre-wake state.
        if force_smart or wait:
            self.tick_lock.acquire()
        else:
            if not self.tick_lock.acquire(blocking=False):
                # Normal for a moment. But if a collection drags on, nothing is
                # being recorded — say so, rather than going quiet the way an
                # eight-hour stall once did until someone looked at the charts.
                started = self._tick_started
                if started and time.time() - started > 300 \
                        and time.time() - self._stall_logged > 300:
                    self._stall_logged = time.time()
                    log(f"a collection has been running for "
                        f"{int(time.time() - started)}s — polls are being "
                        f"skipped and no history is being recorded")
                return
        self._tick_started = time.time()
        try:
            self._tick_locked(force_smart=force_smart, refresh=refresh)
        finally:
            took = time.time() - self._tick_started
            self._tick_started = 0.0
            self.tick_lock.release()
            if took > 60:
                log(f"collection took {int(took)}s")

    def _tick_locked(self, *, force_smart: bool, refresh: bool = False) -> None:
        now = time.time()
        tok = self._get_plex_token()

        # daily guaranteed SMART sweep
        do_daily = False
        lt = time.localtime(now)
        if lt.tm_hour == SMART_DAILY_AT and now - self._last_daily > 3600:
            do_daily = True
            self._last_daily = now

        force = force_smart or do_daily or now < self._wake_deadline

        # Everything below runs WITHOUT the lock. Collecting SMART from disks that
        # are spinning up can take tens of seconds, and holding the lock across it
        # would stall every API read (/data.json would time out — which is exactly
        # what happened, and the browser closing the connection then showed up as
        # BrokenPipe). We build a fresh snapshot here and only take the lock for
        # the instant it takes to publish it; a reference assignment is atomic, so
        # readers always see a complete snapshot, never a half-built one.
        # While a wake is spinning the disks up, don't read SMART at all. The
        # O_DIRECT probe moves the kernel I/O counters, so the disks look active
        # to the normal inference and a routine tick would happily fire smartctl
        # at a drive that is still coming up to speed — which fails, falls back
        # to cache, and holds the collection lock while it does. The wake worker
        # runs the real SMART pass the moment every drive is ready.
        read_smart = not (self._spinning_up and not force_smart)
        # Is this the pass that records a history sample? Decide before
        # collecting, so the SMART read can be aligned with it.
        # A forced pass (wake, daily sweep) should land a sample too — its SMART
        # reading is the freshest we get. But every tick inside the two-minute
        # wake window is "forced", and recording each of them filled the history
        # with samples seconds apart. That wrecks the spacing the charts rely on:
        # the median gap collapses, and normal five-minute gaps then look like
        # outages. So a forced pass may add a sample, but no more than once a
        # minute.
        do_slow = now - self._last_slow >= (60 if force else SLOW_INTERVAL)
        # `refresh` bypasses the read throttle but not the sleep rule: disks that
        # are already turning get re-read now, sleeping ones are left alone.
        disks = self.mon.collect(force=force, read_smart=read_smart,
                                 align_smart=do_slow or refresh)

        # While a wake is spinning the platters up, say so. Without this the
        # disks keep reporting the standby they were in when the request came
        # in — for the 10–30 s a five-disk spin-up takes, the dashboard and
        # --diag look like nothing happened at all.
        if self._spinning_up:
            for d in disks:
                if d.get("tran") != "nvme" and d.get("mount") not in (None, "/"):
                    d["power"] = "spinning"
                    d["power_src"] = "wake in progress — spinning up"
        if force:
            self.mon.create_probes(disks)
            n = self.mon.mark_smart_read(disks)
            if n:
                log(f"SMART read from {n} disk(s)"
                    + (" (daily)" if do_daily else ""), level="debug")
                # The wake window keeps the fast loop retrying SMART. Clear it
                # when every spinning disk has answered — clearing on the first
                # partial success (e.g. the one disk already awake for playback)
                # used to leave the rest cached until a second click.
                usb = [d for d in disks if d.get("tran") != "nvme"]
                self._wake_passes += 1
                if usb and all(not d.get("from_cache") for d in usb):
                    self._wake_deadline = 0.0
                    self._wake_passes = 0
                elif self._wake_passes >= 3:
                    # A disk that still won't answer after three passes isn't
                    # going to: stop, rather than spinning every other disk up
                    # once per tick for the rest of the window.
                    missing = [d.get("dev") for d in usb if d.get("from_cache")]
                    log(f"giving up on SMART for {', '.join(missing)} after "
                        f"{self._wake_passes} passes")
                    self._wake_deadline = 0.0
                    self._wake_passes = 0

        system = read_system()
        np = sessions(tok, mount_list())
        cache_art(np, tok)
        attach_atv(np)
        acts = activity(self._get_roots(tok))
        srv = server_info(tok)
        srv["sessions"] = len(np)
        overall, reasons = assess(disks, system)

        # A forced pass is a full collector run: refresh perf/DB too and record a
        # history sample, exactly like the PHP collector did on its wake pass.
        # This also lands a fresh Start_Stop reading in the history right away,
        # which is what the per-hour/day spin-up figures are computed from.
        # (do_slow was decided before the collection, so the SMART read could
        # be aligned with the history sample)
        if do_slow:
            self._last_slow = now
            pf = perf(tok)
            self._samples = record(
                getattr(self, "_samples", load()),
                disks, system, pf, srv)
            full = series(self._samples, disks, 0)
            write_json(HISTORY_WEB, full, mode=0o644)
            self._perf = pf
            self._hist_disks = disks
        pf = getattr(self, "_perf", {"direct": {}, "proxy": None, "db": {}})
        samples = getattr(self, "_samples", load())

        hist = series(samples, disks, HISTORY_POINTS)
        new_snapshot = self._build_snapshot(
            disks, system, np, acts, srv, pf, overall, reasons, hist, samples)

        # publish atomically — the only thing the lock protects
        with self.lock:
            self.snapshot = new_snapshot
        write_json(DATA_FILE, new_snapshot, mode=0o644)
        write_json(SESSIONS_WEB,
                   {"generated": int(now), "sessions": np}, mode=0o644)

    def _build_snapshot(self, disks, system, np, acts, srv, pf,
                        overall, reasons, hist, samples) -> dict:
        for d in disks:
            key = d.get("hist_key") or d.get("serial") or d.get("dev")
            d["spinups_1h"] = spinups_window(samples, key, 3600)
            d["spinups_24h"] = spinups_window(samples, key, 86400)
        return {
            "generated": int(time.time()),
            "hostname": os.uname().nodename,
            "overall": overall,
            "reasons": reasons,
            "thresholds": {"temp_warn": TEMP_WARN, "temp_crit": TEMP_CRIT},
            "last_smart_read": self.mon.last_smart_read,
            "system": system,
            "plex": srv,
            "now_playing": np,
            "activity": acts,
            "perf": pf,
            "history": hist,
            "disks": disks,
        }

    # ---- wake handling ---------------------------------------------------
    def _poster_bytes(self, key: str) -> Optional[bytes]:
        """
        Poster image bytes for a Plex metadata key. Serves the cached file if the
        collector already fetched it, otherwise fetches live from Plex (and drops
        a cached copy for next time). Returns None if there's no image.
        """
        import hashlib as _hl
        name = "art-" + _hl.md5(key.encode()).hexdigest()[:16] + ".jpg"
        path = WEB_DIR / name
        try:
            if path.is_file() and path.stat().st_size > 200:
                return path.read_bytes()
        except OSError:
            pass
        tok = self._get_plex_token()
        if not tok:
            return None
        img = _api(key, tok, as_json=False)
        if isinstance(img, (bytes, bytearray)) and len(img) > 200:
            write_bytes_atomic(path, bytes(img), mode=0o644)
            return bytes(img)
        return None

    def request_wake(self) -> dict:
        """Read the probe files (spins the disks up) and force a SMART pass."""
        with self.lock:
            snap_disks = self.snapshot.get("disks", [])
        # is_file() on a data-disk mount can stall if the disk is spinning up, so
        # do it outside the lock — otherwise a wake request would hold the lock
        # exactly when the API needs it most.
        mounts = []
        for d in snap_disks:
            mp = d.get("mount")
            if mp and mp != "/" and d.get("tran") != "nvme":
                # No is_file() filter here: on a fresh install the probes don't
                # exist yet (a forced pass creates them), and filtering on them
                # meant the first wake had nothing to spin up. The worker creates
                # a missing probe itself — the write wakes the disk just as well.
                mounts.append((mp, d.get("dev"), d.get("path")))

        def worker():
            # Spin every disk up FIRST and wait for it: the O_DIRECT probe read
            # blocks until the platters turn, so by the time we run the SMART
            # pass the drives can actually answer. Firing smartctl in parallel
            # with the spin-up (the previous behaviour) meant the first click
            # only got SMART from disks that happened to be awake already — the
            # rest failed mid-spin-up, were served from cache, and looked like
            # they needed a second click.
            def spin(mp, dev_path):
                probe = Path(mp) / ".wake-probe"
                try:
                    if not probe.is_file():
                        probe.write_bytes(b"\0" * 65536)
                        probe.chmod(0o644)
                except OSError:
                    pass
                self._probe_read(probe, dev_path)

            self._spinning_up = True
            # Publish the spinning state right away — the fast loop would
            # otherwise leave the page showing the old standby for up to a full
            # interval, which reads as "the button did nothing".
            threading.Thread(target=lambda: self._tick(force_smart=False, wait=True),
                             daemon=True).start()
            try:
                threads = []
                for mp, _dev, dev_path in mounts:
                    t = threading.Thread(target=spin, args=(mp, dev_path), daemon=True)
                    t.start()
                    threads.append(t)
                for t in threads:
                    t.join(timeout=25)      # a 3.5" drive spins up in ~10 s
            finally:
                self._spinning_up = False
            # Only now open the forced-SMART window: opening it up front let the
            # fast loop fire smartctl at disks that were still spinning up, which
            # is exactly the failure this worker exists to avoid.
            self._wake_deadline = time.time() + 120
            self._wake_passes = 0
            self._tick(force_smart=True)

        threading.Thread(target=worker, daemon=True).start()
        return {"ok": True, "at": int(time.time()),
                "disks": [d for _, d, _p in mounts],
                # the daemon always re-reads SMART itself (it runs as root), so the
                # page can count on fresh values — no sudo rule involved anymore
                "refresh": True}

    @staticmethod
    def _probe_read(path: Path, dev_path: Optional[str] = None) -> None:
        """
        Force a physical read so a sleeping drive spins up, and block until it
        has. O_DIRECT is what makes this work: it bypasses the page cache, so the
        read cannot be answered from RAM and must reach the platters.

        The buffer alignment matters and is easy to get wrong. O_DIRECT requires
        a memory-aligned buffer; os.pread() allocates an ordinary bytes object,
        which the kernel rejects with EINVAL. That failure used to fall through
        to a buffered read — served straight from the page cache, waking nothing
        — so the probe silently did nothing at all and the disks were only ever
        spun up as a side effect of smartctl. mmap gives us a page-aligned
        buffer, and os.preadv() reads into it.

        Prefers the raw block device (a read there cannot be short-circuited by
        the filesystem) and falls back to the probe file on the mount.
        """
        import mmap

        def direct_read(target: str) -> bool:
            try:
                fd = os.open(target, os.O_RDONLY | os.O_DIRECT)
            except OSError:
                return False
            try:
                buf = mmap.mmap(-1, 4096)          # page-aligned by definition
                try:
                    os.preadv(fd, [buf], 0)
                    return True
                finally:
                    buf.close()
            except OSError:
                return False
            finally:
                os.close(fd)

        if dev_path and direct_read(dev_path):
            return
        if direct_read(str(path)):
            return
        # Last resort: a buffered read may be served from cache and wake nothing,
        # but it is better than giving up entirely.
        try:
            with open(path, "rb") as f:
                f.read(4096)
        except OSError:
            pass

    def wakecheck(self) -> dict:
        """
        Report which disks are spun up — from the I/O-counter state the daemon
        already samples, never by touching the disk. A probe read here would take
        seconds on a sleeping disk (holding the request open) and, worse, would
        spin it up: exactly what a *check* must not do. The fast loop refreshes
        this every FAST_INTERVAL, so it's already current.
        """
        with self.lock:
            disks = self.snapshot.get("disks", [])
        result = {}
        for d in disks:
            mp = d.get("mount")
            if not mp or mp == "/" or d.get("tran") == "nvme":
                continue
            # a disk we read SMART from this cycle, or that shows recent I/O, is up
            result[d.get("dev")] = (not d.get("from_cache", True)) or d.get("power") == "active"
        awake = sum(1 for v in result.values() if v)
        return {"ok": True, "disks": result, "awake": awake, "total": len(result)}

    # ---- HTTP API --------------------------------------------------------
    def _serve_api(self) -> None:
        daemon = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, obj, ctype="application/json"):
                body = (json.dumps(obj).encode() if ctype == "application/json"
                        else obj)
                try:
                    self.send_response(code)
                    self.send_header("Content-Type", ctype)
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError):
                    # the browser closed the connection before we finished (a poll
                    # that got superseded, a page reload) — harmless, not an error
                    pass

            def handle_one_request(self):
                # same swallow at the request level, in case the disconnect lands
                # between reading the request line and our handler
                try:
                    super().handle_one_request()
                except (BrokenPipeError, ConnectionResetError):
                    self.close_connection = True

            def _authed(self) -> bool:
                sent = self.headers.get("X-Plexmon-Token", "")
                return secrets.compare_digest(sent, daemon.token)

            def do_GET(self):
                path = urlparse(self.path).path
                if path == "/data.json":
                    # Grab the reference under the lock, then send OUTSIDE it. The
                    # snapshot is only ever replaced, never mutated in place, so
                    # the reference is a consistent view. Sending under the lock
                    # was the bug: a slow or half-closed client made wfile.write
                    # block while holding the lock, stalling every other reader
                    # (that's why /data.json and /wakecheck timed out during wake).
                    with daemon.lock:
                        snap = daemon.snapshot
                    self._send(200, snap)
                elif path == "/history-full.json":
                    self._send(200, read_json(HISTORY_WEB, {}))
                elif path == "/sessions":
                    # Query Plex live rather than returning the last tick's copy:
                    # a session poll is cheap (Plex API only, no disk access) and
                    # this is what keeps Now Playing responsive instead of lagging
                    # up to a full fast-loop interval behind.
                    tok = daemon._get_plex_token()
                    try:
                        np = sessions(tok, mount_list())
                        cache_art(np, tok)
                        attach_atv(np)
                        acts = activity(daemon._get_roots(tok))
                        self._send(200, {"generated": int(time.time()),
                                         "sessions": np, "activity": acts})
                    except Exception:
                        # fall back to the snapshot if Plex is momentarily unreachable
                        with daemon.lock:
                            snap = daemon.snapshot
                        self._send(200, {"generated": snap.get("generated"),
                                         "sessions": snap.get("now_playing", []),
                                         "activity": snap.get("activity", [])})
                elif path == "/wakecheck":
                    self._send(200, daemon.wakecheck())
                elif path == "/art":
                    # Serve a poster directly: fetch from Plex if not cached yet.
                    # This makes Now Playing artwork appear immediately instead of
                    # waiting for the next collection to write the file.
                    from urllib.parse import parse_qs
                    q = parse_qs(urlparse(self.path).query)
                    key = (q.get("key") or [""])[0]
                    if not key.startswith("/library/"):
                        self._send(400, {"error": "bad key"})
                    else:
                        img = daemon._poster_bytes(key)
                        if img:
                            self._send(200, img, ctype="image/jpeg")
                        else:
                            self._send(404, {"error": "no poster"})
                elif path == "/atv":
                    ok, why = atv_ready()
                    devs = []
                    if ok:
                        for d in atv_devices():
                            devs.append({**d, "kind": "appletv"})
                        # The other makes are only known once seen, so they come
                        # from what has been paired rather than from a scan.
                        for addr, rec in _tv_load().items():
                            devs.append({"kind": rec.get("kind"), "address": addr,
                                         "ident": addr,
                                         "name": rec.get("name") or addr,
                                         "paired": True})
                    self._send(200, {"ok": ok, "reason": why, "devices": devs})
                elif path == "/health":
                    self._send(200, {"ok": True, "uptime": int(time.time() - START)})
                else:
                    self._send(404, {"error": "not found"})

            def do_POST(self):
                path = urlparse(self.path).path
                if not self._authed():
                    self._send(403, {"ok": False, "error": "bad or missing token"})
                    return
                if path.startswith("/atv/"):
                    from urllib.parse import parse_qs
                    q = parse_qs(urlparse(self.path).query)
                    ident = (q.get("id") or [""])[0]
                    action = path[len("/atv/"):]
                    if action == "rescan":
                        self._send(200, {"ok": True, "devices": atv_scan(force=True)})
                    elif action == "key":
                        ok, msg = samsung_send_key(ident, (q.get("k") or [""])[0])
                        self._send(200 if ok else 409, {"ok": ok, "message": msg})
                    elif action == "probe":
                        kind = tv_probe(ident)
                        self._send(200, {"ok": bool(kind), "kind": kind,
                                         "name": tv_name(ident, kind) if kind else None,
                                         "message": ("found" if kind else
                                                     "nothing answers at that address")})
                    elif action == "unpair-all":
                        ok1, m1 = atv_unpair_all()
                        ok2, m2 = tv_unpair_all()
                        self._send(200 if (ok1 or ok2) else 409,
                                   {"ok": ok1 or ok2, "message": f"{m1}; {m2}"})
                    elif not ident:
                        self._send(400, {"ok": False, "error": "no device id"})
                    elif action == "pair":
                        kind = (q.get("kind") or ["appletv"])[0]
                        if kind == "appletv":
                            ok, msg = atv_pair_start(ident)
                            # Apple TVs show a code that has to be typed back;
                            # the others just want the prompt accepted on screen.
                            self._send(200 if ok else 409,
                                       {"ok": ok, "message": msg, "needs_pin": True})
                        else:
                            ok, msg = tv_pair(ident)
                            self._send(200 if ok else 409,
                                       {"ok": ok, "message": msg, "needs_pin": False})
                    elif action == "pin":
                        ok, msg = atv_pair_pin(ident, (q.get("pin") or [""])[0])
                        self._send(200 if ok else 409, {"ok": ok, "message": msg})
                    elif action == "unpair":
                        kind = (q.get("kind") or ["appletv"])[0]
                        ok, msg = (atv_unpair(ident) if kind == "appletv"
                                   else tv_unpair(ident))
                        self._send(200 if ok else 409, {"ok": ok, "message": msg})
                    elif action == "cmd":
                        kind = (q.get("kind") or ["appletv"])[0]
                        cmdname = (q.get("c") or [""])[0]
                        if kind == "appletv":
                            ok, msg = atv_command(ident, cmdname)
                        else:
                            # For the other makes the identifier is the address,
                            # and LG needs to know which way to toggle.
                            playing = (q.get("playing") or ["1"])[0] != "0"
                            ok, msg = tv_command(ident, cmdname, playing)
                        self._send(200 if ok else 409, {"ok": ok, "message": msg})
                    else:
                        self._send(404, {"ok": False, "error": "unknown action"})
                    return

                if path == "/wake":
                    self._send(200, daemon.request_wake())
                elif path == "/smart":
                    # Refresh, not wake: re-read SMART from every disk that is
                    # already spinning, and leave the sleeping ones asleep. Use
                    # /wake when you want them spun up first.
                    threading.Thread(
                        target=lambda: daemon._tick(force_smart=False, refresh=True),
                        daemon=True).start()
                    with daemon.lock:
                        awake = [d.get("dev") for d in daemon.snapshot.get("disks", [])
                                 if d.get("power") == "active"]
                    self._send(200, {"ok": True, "refreshing": awake})
                else:
                    self._send(404, {"error": "not found"})

        global START
        START = time.time()
        ThreadingHTTPServer.allow_reuse_address = True
        try:
            srv = ThreadingHTTPServer((API_HOST, API_PORT), Handler)
        except OSError as e:
            # No point running without the API — the whole daemon is only useful
            # if the page can reach it. Exit so systemd restarts us cleanly once
            # whatever holds the port is gone.
            log(f"cannot bind {API_HOST}:{API_PORT}: {e} — is another plexmon "
                f"already running? exiting")
            os._exit(1)
        srv.serve_forever()




def _atv_api(path: str, method: str = "GET", timeout: float = 0.0):
    if not timeout:
        # Pairing waits on a person, not a machine.
        timeout = TV_PAIR_TIMEOUT * 2 + 20 if "/pair" in path else 60.0
    """
    Talk to the running daemon rather than to the credential file. The daemon
    owns the store and the open sessions; a second process writing the same file
    behind its back is how you end up with a pairing that works in one place and
    not the other.
    """
    req = urllib.request.Request(f"http://{API_HOST}:{API_PORT}{path}",
                                 method=method,
                                 data=b"" if method == "POST" else None)
    if method == "POST":
        try:
            req.add_header("X-Plexmon-Token", TOKEN_FILE.read_text().strip())
        except OSError:
            raise RuntimeError("no API token — is the daemon running?")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        # The daemon answers refusals with a JSON reason; showing that beats
        # printing "HTTP Error 409: Conflict" at someone.
        try:
            return json.loads(e.read().decode())
        except Exception:
            raise RuntimeError(f"HTTP {e.code}")


def _looks_like_address(text: str) -> bool:
    """A dotted quad, so an unknown television can be named by where it is."""
    parts = (text or "").split(".")
    return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)


def _atv_pick(devices: list, want: str) -> Optional[dict]:
    """Find a television by identifier or by name, however the user typed it."""
    w = (want or "").strip().lower()
    for d in devices:
        if str(d.get("ident", "")).lower() == w:
            return d
    named = [d for d in devices if str(d.get("name", "")).lower() == w]
    if len(named) == 1:
        return named[0]
    partial = [d for d in devices if w and w in str(d.get("name", "")).lower()]
    if len(partial) == 1:
        return partial[0]
    if len(partial) > 1:
        raise RuntimeError("that matches more than one television: "
                           + ", ".join(d["name"] for d in partial))
    return None


def _atv_print(devices: list) -> None:
    if not devices:
        print("  no televisions found")
        return
    for d in devices:
        mark = f"{G}paired{N}" if d.get("paired") else f"{D}not paired{N}"
        kind = d.get("kind", "appletv")
        print(f"  {d.get('name', '?'):22} {str(d.get('address', '?')):16} "
              f"{D}{kind:8}{N} {mark}")
        print(f"      {D}{d.get('ident', '')}{N}")
        if d.get("model"):
            print(f"      {D}{d['model']}{N}")


def _atv_cli(args) -> int:
    """--atv and friends: list, scan, pair and unpair from the command line."""
    try:
        state = _atv_api("/atv")
    except Exception as e:
        print(f"could not reach the daemon: {e}")
        return 1
    if not state.get("ok"):
        print(f"remote control is unavailable: {state.get('reason')}")
        return 1

    if args.atv_scan:
        print("searching the network…")
        try:
            res = _atv_api("/atv/rescan", "POST")
        except Exception as e:
            print(f"scan failed: {e}")
            return 1
        _atv_print(res.get("devices") or [])
        return 0

    if args.atv_probe:
        try:
            res = _atv_api(f"/atv/probe?id={urllib.parse.quote(args.atv_probe)}", "POST")
        except Exception as e:
            print(f"failed: {e}")
            return 1
        if res.get("ok"):
            print(f"  {G}{res.get('kind')}{N} — {res.get('name')}")
            print(f"  {D}pair it with: plexmon --atv-pair {args.atv_probe}{N}")
            return 0
        print(f"  {res.get('message')}")
        return 1

    if args.atv_unpair_all:
        try:
            res = _atv_api("/atv/unpair-all", "POST")
        except Exception as e:
            print(f"failed: {e}")
            return 1
        print(f"  {res.get('message')}")
        print(f"  {D}the televisions still list this server among their paired"
              f" remotes; remove it there in tvOS settings{N}")
        return 0 if res.get("ok") else 1

    devices = state.get("devices") or []

    if args.atv:
        _atv_print(devices)
        if not any(d.get("paired") for d in devices):
            print(f"\n  {D}pair one with: plexmon --atv-pair \"name\"{N}")
        return 0

    if args.atv_key:
        target, key = args.atv_key
        try:
            dev = _atv_pick(devices, target)
        except RuntimeError as e:
            print(f"  {e}")
            return 1
        addr = (dev or {}).get("address") or (target if _looks_like_address(target) else None)
        if not addr:
            print(f"  no television matches {target!r}")
            return 1
        try:
            res = _atv_api(f"/atv/key?id={urllib.parse.quote(addr)}"
                           f"&k={urllib.parse.quote(key)}", "POST")
        except Exception as e:
            print(f"failed: {e}")
            return 1
        if res.get("ok"):
            print(f"  sent {key} to {addr} — did the television do anything?")
            return 0
        print(f"  {res.get('message')}")
        return 1

    want = args.atv_pair or args.atv_unpair
    try:
        dev = _atv_pick(devices, want)
    except RuntimeError as e:
        print(f"  {e}")
        return 1

    # An LG or Samsung that has never been paired is in no list yet — only Apple
    # TVs announce themselves on the network. Given an address, ask what is there.
    if dev is None and args.atv_pair and _looks_like_address(want):
        try:
            res = _atv_api(f"/atv/probe?id={urllib.parse.quote(want)}", "POST")
        except Exception as e:
            print(f"  could not reach that address: {e}")
            return 1
        if res.get("ok"):
            dev = {"ident": want, "address": want, "kind": res.get("kind"),
                   "name": res.get("name") or want, "paired": False}
        else:
            print(f"  {res.get('message')}")
            return 1

    if dev is None:
        print(f"  no television matches {want!r}. Known:")
        _atv_print(devices)
        if args.atv_pair:
            print(f"\n  {D}an LG or Samsung that has never been paired will not be"
                  f" listed — give its IP address instead{N}")
        return 1

    kind = dev.get("kind", "appletv")

    if args.atv_unpair:
        try:
            res = _atv_api(f"/atv/unpair?id={urllib.parse.quote(dev['ident'])}"
                           f"&kind={kind}", "POST")
        except Exception as e:
            print(f"failed: {e}")
            return 1
        print(f"  {dev['name']}: {res.get('message')}")
        return 0 if res.get("ok") else 1

    # pairing: ask the device for a code, then hand back what the screen shows
    print(f"  pairing with {dev['name']} ({dev['address']})…")
    if kind != "appletv":
        print(f"  {D}accept the prompt that appears on the television{N}")
    try:
        res = _atv_api(f"/atv/pair?id={urllib.parse.quote(dev['ident'])}"
                       f"&kind={kind}", "POST")
    except Exception as e:
        print(f"failed to start pairing: {e}")
        return 1
    if not res.get("ok"):
        print(f"  {res.get('message')}")
        return 1
    if res.get("needs_pin") is False:
        print(f"  {G}paired{N}")
        return 0
    try:
        pin = input("  enter the PIN shown on the television: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n  cancelled")
        return 1
    try:
        res = _atv_api(f"/atv/pin?id={urllib.parse.quote(dev['ident'])}"
                       f"&pin={urllib.parse.quote(pin)}", "POST")
    except Exception as e:
        print(f"failed: {e}")
        return 1
    print(f"  {G}paired{N}" if res.get("ok") else f"  {R}{res.get('message')}{N}")
    return 0 if res.get("ok") else 1


def run_daemon(debug: bool = False) -> int:
    """The daemon in the foreground - what plexmon.service starts
    (plexmon --daemon). One at a time: a second one finds the API taken."""
    set_debug(debug)
    d = Daemon()
    try:
        d.run()
    except KeyboardInterrupt:
        return 0
    return 0


def monitor_cli(args) -> int:
    """The dashboard daemon's own command line: --wake, --refresh, --oneshot,
    --diag and the television remotes - as plexmon.py always had them."""
    set_debug(getattr(args, "debug", False))
    if args.diag:
        return diag()
    if (args.atv or args.atv_scan or args.atv_probe or args.atv_pair
            or args.atv_key or args.atv_unpair or args.atv_unpair_all):
        return _atv_cli(args)
    if args.oneshot:
        d = Daemon()
        d._tick(force_smart=args.wake)
        with d.lock:
            print(json.dumps({"overall": d.snapshot.get("overall"),
                              "disks": len(d.snapshot.get("disks", [])),
                              "sessions": d.snapshot.get("plex", {}).get("sessions"),
                              "last_smart_read": d.snapshot.get("last_smart_read")}))
        return 0
    if args.refresh or args.wake:
        path = "/smart" if args.refresh else "/wake"
        try:
            tok = TOKEN_FILE.read_text().strip()
        except OSError:
            print("no API token — is the daemon running? (systemctl status plexmon)")
            return 1
        req = urllib.request.Request(
            f"http://{API_HOST}:{API_PORT}{path}", method="POST", data=b"")
        req.add_header("X-Plexmon-Token", tok)
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            print(opener.open(req, timeout=8).read().decode())
            return 0
        except Exception as e:
            print(f"could not reach the daemon: {e}")
            return 1
    return 0


def main(argv=None) -> int:
    """plexmon: with nothing at all it says what it is doing; the daemon is
    plexmon --daemon (systemd). Everything goes through Settings' command
    line (plexmon_admin.cli_main), otp's, which hands the dashboard's own
    commands back here."""
    argv = sys.argv[1:] if argv is None else argv
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    try:
        import plexmon_admin
    except Exception as e:                              # noqa: BLE001
        # Settings broken: the dashboard still runs, as it did before 2.0.
        if not argv or "--daemon" in argv:
            print(f"plexmon: Settings cannot be loaded ({e}); the dashboard runs alone",
                  file=sys.stderr)
            return run_daemon("--debug" in argv or "-v" in argv)
        raise
    return plexmon_admin.cli_main(argv, mon=sys.modules[__name__])


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:
        # Read through `| head`: the rest is nobody's, said nowhere.
        try:
            os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        except OSError:
            pass
        sys.exit(0)
    except KeyboardInterrupt:
        sys.exit(130)
