#!/bin/bash
# install.sh - plexmon: the Plex server's dashboard and its Settings.
#
#   ./install.sh                 install (a fresh machine, or over the old
#                                plexmon / plex-status.service - it is taken
#                                over: its history, its config, its limits)
#   ./install.sh --upgrade       put this version in over an installed one
#   ./install.sh --upgrade --yes the same, asking nothing (what Settings →
#                                Upgrades runs, as root, through
#                                plexmon-upgrade.service)
#   ./install.sh --uninstall     take plexmon away (the history, the config
#                                and nginx's files are left as they are)
#
# PHP (php2shell, CVE-2026-109618 / CVE-2026-109619 - fixed 21 October 2026),
# as otp does it - on every install and every upgrade:
#   --php-stream X.Y             the AppStream stream PHP is put on (8.3 - at least 8.3.36);
#                                an older PHP (8.0, 8.1, 8.2) is moved onto it, a newer fixed
#                                one (8.4) is left as it is
#   --remi                       PHP 8.4 from Remi's repository instead
#   --no-php-update              PHP left as it is (still checked, still guarded)
#
# What it never does: touch Plex Media Server, its library or its database,
# change the Plex reverse proxy beyond handing its TLS lines and the ACME
# answers to plexmon (once, checked with nginx -t, put back on any doubt), or
# wake a sleeping disk.
set -u
umask 022

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(sed -n "s/^__version__ = '\([0-9.]*\)'.*/\1/p" "$HERE/plexmon_admin.py" | head -1)"
FLOOR="$(sed -n "s/^DOWNGRADE_FLOOR = '\([0-9.]*\)'.*/\1/p" "$HERE/plexmon_admin.py" | head -1)"
LIB=/usr/local/lib/plexmon
BIN=/usr/local/bin/plexmon
WEB=/var/www/html/smart
STATE=/var/lib/plexmon
OLD_STATE=/var/lib/plex-status
ETC=/etc/plexmon
LOGS=/var/log/plexmon
ACME_ROOT=/var/www/plexmon-acme
UNITS=/etc/systemd/system
NGINX_SITE=/etc/nginx/conf.d/plex.conf

MODE=install
YES=0
PHP_UPDATE=yes
PHP_STREAM=8.3
PHP_MIN=8.3.36
USE_REMI=""
while [ $# -gt 0 ]; do
    case "$1" in
        --upgrade) MODE=upgrade ;;
        --uninstall) MODE=uninstall ;;
        --yes|-y) YES=1 ;;
        --php-stream) PHP_STREAM="${2:-8.3}"; shift ;;
        --remi) USE_REMI=yes ;;
        --no-php-update) PHP_UPDATE="" ;;
        --help|-h) sed -n '2,27p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "install.sh: what is $1? (--upgrade, --uninstall, --yes, --php-stream X.Y, --remi, --no-php-update, --help)"; exit 2 ;;
    esac
    shift
done

if [ -t 1 ] && [ "${TERM:-dumb}" != dumb ]; then
    G=$'\033[32m'; Y=$'\033[33m'; R=$'\033[31m'; B=$'\033[1m'; D=$'\033[2m'; N=$'\033[0m'
else
    G=; Y=; R=; B=; D=; N=
fi
step() { echo; echo "==> $*"; }
say()  { echo "    $*"; }
ok()   { echo "    ${G}ok${N} $*"; }
warn() { echo "    ${Y}warning${N} $*"; }
die()  { echo "    ${R}failed${N} $*"; exit 1; }
ask()  {
    [ "$YES" = 1 ] && return 0
    [ -t 0 ] || return 0
    read -r -p "    $* (Y/n) " got
    case "$got" in n|N|no|ne) return 1 ;; *) return 0 ;; esac
}

[ "$(id -u)" = 0 ] || die "run it as root (sudo ./install.sh)"
[ -n "$VERSION" ] || die "this is not a plexmon package: plexmon_admin.py has no version"

# How far an upgrade is, for the pages (2.9.9): a file beside them that their PHP reads straight
# from the disk - plexmon's API, nginx and php-fpm restart during an upgrade, and the pages show
# the step all the same. Named .php and starting with exit, so the web server never shows it;
# written whole (a new file renamed over it), 0644, nothing secret in it. Each step() is a step;
# the end - done, or failed with the exit code, also when stopped by a signal - from the trap.
# Never a reason for the upgrade to fail: every write is best effort.
UP_TELL=""
if [ "$MODE" = upgrade ] && [ -d "$WEB" ] && [ ! -L "$WEB" ]; then
    UP_TELL=1
    UP_PART=0; UP_PARTS=12
    if [ "${PLEXMON_UPGRADE_FROM_PAGES:-}" = 1 ]; then UP_PART=1; UP_PARTS=13; fi
    UP_ID="$(printf '%s' "${PLEXMON_UPGRADE_ID:-sh$(date +%s)}" | tr -cd 'A-Za-z0-9._-' | cut -c1-64)"
    UP_STARTED="${PLEXMON_UPGRADE_STARTED:-}"
    [[ "$UP_STARTED" =~ ^[0-9]+$ ]] || UP_STARTED="$(date +%s)"
    UP_FROM="${PLEXMON_UPGRADE_FROM:-$(sed -n "s/^__version__ = '\([0-9.]*\)'.*/\1/p" "$LIB/plexmon_admin.py" 2>/dev/null | head -1)}"
    UP_BY="${PLEXMON_UPGRADE_BY:-root on the command line}"
    UP_DOWN=false
    [ -n "${PLEXMON_UPGRADE_DOWN:-}" ] && UP_DOWN=true
    UP_ENDED=""
fi
up_esc() { printf '%s' "$1" | tr -d '\000-\037\177' | sed 's/\\/\\\\/g; s/"/\\"/g' | cut -c1-"$2"; }
upgrade_tell() {        # upgrade_tell STATE WORDS [SAID]
    [ -n "$UP_TELL" ] || return 0
    local tmp="$WEB/.plexmon-upgrade.$$.tmp.php"
    {
        printf '<?php exit; ?>\n'
        printf '{"state": "%s", "id": "%s", "version": "%s", "from": "%s", "by": "%s", "part": %d, "parts": %d, "words": "%s", "started": %d, "at": %d, "said": "%s", "downgrade": %s}\n' \
            "$1" "$UP_ID" "$(printf '%s' "$VERSION" | tr -cd '0-9.')" "$(printf '%s' "$UP_FROM" | tr -cd '0-9.')" \
            "$(up_esc "$UP_BY" 100)" "$UP_PART" "$UP_PARTS" "$(up_esc "$2" 160)" "$UP_STARTED" "$(date +%s)" \
            "$(up_esc "${3:-}" 300)" "$UP_DOWN"
    } > "$tmp" 2>/dev/null && chmod 0644 "$tmp" 2>/dev/null && mv -f "$tmp" "$WEB/.plexmon-upgrade.php" 2>/dev/null \
        || rm -f "$tmp" 2>/dev/null
    return 0
}
step() {
    echo; echo "==> $*"
    if [ -n "$UP_TELL" ]; then
        UP_PART=$((UP_PART + 1)); [ "$UP_PART" -gt "$UP_PARTS" ] && UP_PART=$UP_PARTS
        upgrade_tell running "$*"
    fi
    return 0
}
upgrade_end() {
    local rc=$?
    [ -n "$UP_TELL" ] && [ -z "$UP_ENDED" ] || return 0
    UP_ENDED=1
    if [ "$rc" = 0 ]; then
        UP_PART=$UP_PARTS; upgrade_tell done "plexmon $VERSION runs"
    else
        upgrade_tell failed "" "install.sh --upgrade stopped (exit $rc)"
    fi
    return 0
}
if [ -n "$UP_TELL" ]; then
    trap upgrade_end EXIT
    trap 'exit 130' INT; trap 'exit 129' HUP; trap 'exit 143' TERM
fi

# ---------------------------------------------------------------------------
if [ "$MODE" = uninstall ]; then
    step "Taking plexmon away"
    ask "plexmon, its Settings and its units are taken away (the history in $OLD_STATE, $ETC and nginx's certificates stay). Go on?" || exit 1
    systemctl disable --now plexmon.service plexmon-upgrade.path 2>/dev/null
    rm -f "$UNITS/plexmon.service" "$UNITS/plexmon-upgrade.path" "$UNITS/plexmon-upgrade.service" \
          "$UNITS/plex-status.service" /etc/profile.d/zz-plexmon-console.sh "$BIN" \
          /etc/logrotate.d/plexmon /etc/sysctl.d/80-plexmon-console.conf
    # SELinux (2.9.0): plexmon's module goes with it; the mode, the booleans and the ports are
    # the machine's and stay.
    for m in plexmon_local plexmon_server; do
        if command -v semodule >/dev/null 2>&1 && semodule -l 2>/dev/null | awk -v m="$m" '$1==m{f=1} END{exit !f}'; then
            semodule -r "$m" >/dev/null 2>&1 && ok "SELinux: plexmon's module ($m) taken out of the policy"
        fi
    done
    rm -rf "$LIB"
    rm -rf "$WEB/settings" "$WEB/assets" "$WEB/lang" "$WEB/plexmon-page.php" "$WEB/plexmon-admin-api.php"
    systemctl daemon-reload
    if grep -q "include /etc/nginx/plexmon/" "$NGINX_SITE" 2>/dev/null; then
        say "$NGINX_SITE still includes /etc/nginx/plexmon/ - left as it is, so nginx keeps"
        say "working; the copy from before plexmon is in $STATE/backup/."
    fi
    ok "plexmon is gone; the database and the backups are in $STATE"
    exit 0
fi

# ---------------------------------------------------------------------------
step "plexmon $VERSION - $([ "$MODE" = upgrade ] && echo upgrade || echo installing) on $(hostname)"
HAVE=""
[ -f "$LIB/plexmon_admin.py" ] && HAVE="$(sed -n "s/^__version__ = '\([0-9.]*\)'.*/\1/p" "$LIB/plexmon_admin.py" | head -1)"
OLD_UNIT=""
[ -f "$UNITS/plex-status.service" ] && [ ! -L "$UNITS/plex-status.service" ] && OLD_UNIT="$UNITS/plex-status.service"
if [ -n "$HAVE" ]; then
    say "installed now: plexmon $HAVE"
elif [ -n "$OLD_UNIT" ] || [ -f "$LIB/plexmon.py" ]; then
    say "installed now: the plexmon before Settings (plex-status.service) - it is taken over"
else
    say "nothing installed yet"
fi
if [ "$MODE" = upgrade ] && [ -n "$HAVE" ] && [ "${PLEXMON_UPGRADE_FROM_PAGES:-}" != 1 ]; then
    newer=$(printf '%s\n%s\n' "$HAVE" "$VERSION" | sort -V | tail -1)
    if [ "$newer" != "$VERSION" ] && [ "$HAVE" != "$VERSION" ]; then
        ask "$HAVE is newer than $VERSION - go back to $VERSION?" || exit 1
    fi
fi

# ---------------------------------------------------------------------------
step "What it needs"
PY=""
# The interpreter the daemon ran on before (python3.12 for the TV remotes'
# libraries), else the newest one there is - 3.9 at least.
for unit in "$UNITS/plexmon.service" "$UNITS/plex-status.service"; do
    if [ -f "$unit" ] && [ ! -L "$unit" ]; then
        cand=$(sed -n 's/^ExecStart=\(\S*python3[0-9.]*\)\s.*/\1/p' "$unit" | head -1)
        if [ -n "$cand" ] && [ -x "$cand" ]; then PY="$cand"; break; fi
    fi
done
if [ -z "$PY" ]; then
    for cand in /usr/bin/python3.13 /usr/bin/python3.12 /usr/bin/python3.11 /usr/bin/python3; do
        [ -x "$cand" ] && { PY="$cand"; break; }
    done
fi
[ -n "$PY" ] || die "no python3 - dnf install -y python3"
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' \
    || die "$PY is older than 3.9"
ok "python: $PY ($("$PY" -c 'import platform; print(platform.python_version())'))"

# The newest Python AlmaLinux / RHEL 9 ships (2.2.0): 3.14, 3.13 or 3.12 from
# AppStream, put in beside the system's python3 (which dnf itself runs on and
# which is never touched). The daemon moves to it only when everything it
# imports imports there - the libraries of the TV remotes put in with its own
# pip first; anything short of that and it stays on the one it has.
# PLEXMON_KEEP_PYTHON=1 leaves the interpreter as it is.
py_ver() { "$1" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null; }
py_newest() {
    [ "${PLEXMON_KEEP_PYTHON:-}" = 1 ] && { ok "python: kept as it is (PLEXMON_KEEP_PYTHON=1)"; return 0; }
    command -v dnf >/dev/null || return 0
    local have want="" v cand mods m missing=""
    have=$(py_ver "$PY")
    for v in 3.14 3.13 3.12; do
        [ "$(printf '%s\n%s\n' "$v" "$have" | sort -V | tail -1)" = "$have" ] && break
        if [ -x "/usr/bin/python$v" ] || dnf -q list --available "python$v" >/dev/null 2>&1; then
            want="$v"; break
        fi
    done
    if [ -z "$want" ]; then ok "python: $have is the newest there is for this system"; return 0; fi
    cand="/usr/bin/python$want"
    say "python $want is there for this system (the daemon runs on $have) - putting it in beside it"
    if [ ! -x "$cand" ] || ! "$cand" -m pip --version >/dev/null 2>&1; then
        if ! dnf -y -q install "python$want" "python$want-pip" >/dev/null 2>&1; then
            warn "python $want could not be put in (dnf) - the daemon stays on $have"; return 0
        fi
    fi
    [ -x "$cand" ] || { warn "python $want is not at $cand - the daemon stays on $have"; return 0; }
    # What the daemon imports beyond the standard library, wherever the old
    # interpreter has it: the same put in for the new one.
    mods=""
    for m in colorama aiowebostv samsungtvws; do
        "$PY" -c "import $m" >/dev/null 2>&1 && mods="$mods $m"
    done
    for m in $mods; do
        "$cand" -c "import $m" >/dev/null 2>&1 && continue
        "$cand" -m pip install -q --disable-pip-version-check "$m" >/dev/null 2>&1 \
            || dnf -y -q install "python$want-$m" >/dev/null 2>&1 || true
    done
    for m in sqlite3 ssl curses json asyncio $mods; do
        "$cand" -c "import $m" >/dev/null 2>&1 || missing="$missing $m"
    done
    if [ -n "$missing" ]; then
        warn "python $want lacks:$missing - the daemon stays on $have"; return 0
    fi
    for m in plexmon.py plexmon_admin.py plexmon_plex.py plexmon_host.py deploy/plexmon_upgrade.py; do
        [ -f "$HERE/$m" ] || continue
        if ! "$cand" -c 'import ast, sys; ast.parse(open(sys.argv[1]).read())' "$HERE/$m" 2>/dev/null; then
            warn "python $want does not read $m - the daemon stays on $have"; return 0
        fi
    done
    ok "python: $have -> $want ($cand; the system's python3 left as it is)"
    PY="$cand"
}
py_newest
command -v openssl >/dev/null || die "openssl is needed (dnf install -y openssl)"
ok "openssl: $(openssl version | awk '{print $2}')"
if command -v nginx >/dev/null; then ok "nginx: $(nginx -v 2>&1 | sed 's/.*\///')"; else warn "nginx is not installed - the dashboard and Settings need it in front"; fi
# ---------------------------------------------------------------------------
# PHP, fixed against php2shell - as otp does it
# ---------------------------------------------------------------------------
# On 21 October 2026 PHP fixed two remote code execution flaws reached through
# how PHP takes a request apart before any page runs (CVE-2026-109618,
# CVE-2026-109619). Fixed upstream: 8.2.35, 8.3.36, 8.4.27, 8.5.12. AlmaLinux
# 9 rebuilt its streams the same day - php:8.3 is 8.3.36, php:8.2 is 8.2.35,
# its default 8.0 has the fix backported and keeps its number - so the
# package's changelog is read as well as the version.
#
# What this does: a PHP already fixed is left exactly as it is; one that is
# not has its packages brought up to the newest build on the stream it is on
# (never switched to another stream by itself - that would move every PHP
# site on the machine); where AppStream has no fixed build, Remi's PHP 8.4 is
# offered (asked, or --remi; never during an upgrade by itself). Either way
# the guard goes on: upload progress off and strict sessions for every PHP on
# the machine, and nginx refusing a multipart body to plexmon's pages, which
# take no request body apart (they read php://input).
PKG=""
command -v dnf >/dev/null 2>&1 && PKG=dnf
[ -z "$PKG" ] && command -v apt-get >/dev/null 2>&1 && PKG=apt
OS_MAJOR="$(sed -n 's/^VERSION_ID="\{0,1\}\([0-9]*\).*/\1/p' /etc/os-release 2>/dev/null | head -1)"
PHP_RELOAD=""

php_fpm_units() {
    local found="" listed unit
    systemctl cat php-fpm.service >/dev/null 2>&1 && found="php-fpm"
    listed="$(systemctl list-unit-files --no-legend 'php*-fpm.service' 2>/dev/null || true)"
    for unit in $(awk '{print $1}' <<< "$listed" | sed 's/\.service$//'); do
        [[ -n "$unit" && "$unit" != "php-fpm" && "$unit" =~ ^php[0-9.]*-fpm$ ]] && found="$found $unit"
    done
    echo "$found"
}
php_fpm_bin() {         # the php-fpm that serves the pages: the newest one installed
    local b
    b="$(command -v php-fpm 2>/dev/null || true)"
    [[ -z "$b" && -x /usr/sbin/php-fpm ]] && b=/usr/sbin/php-fpm
    [[ -z "$b" ]] && b="$(ls -1 /usr/sbin/php-fpm[0-9]* 2>/dev/null | sort -V | tail -n 1 || true)"
    echo "$b"
}
php_fpm_version() {     # from php-fpm itself, not the command-line php
    local b v
    b="$(php_fpm_bin)"
    [[ -n "$b" ]] || { echo ""; return; }
    v="$("$b" -v 2>/dev/null | head -n 1 | awk '{print $2}')"
    echo "${v%%[-+~]*}"
}
ver_ge() { [[ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n 1)" == "$2" ]]; }
php_fixed() {           # is the PHP php-fpm runs fixed? 0 yes, 1 no
    local v b f log
    v="$(php_fpm_version)"
    [[ -n "$v" ]] || return 1
    b="$(echo "$v" | cut -d. -f1,2)"
    case "$b" in
        8.2) f=8.2.35 ;; 8.3) f=8.3.36 ;; 8.4) f=8.4.27 ;; 8.5) f=8.5.12 ;;
        *) if ver_ge "$b" 8.6; then return 0; fi; f="" ;;
    esac
    [[ -n "$f" ]] && ver_ge "$v" "$f" && return 0
    # A backport keeps the old number: the changelog says it instead (read
    # whole first, then searched - rpm | grep -q dies on the pipe).
    if [[ "$PKG" == "dnf" ]]; then
        log="$(rpm -q --changelog php-fpm php-common 2>/dev/null || true)"
        grep -q 'CVE-2026-109618' <<< "$log" && return 0
    elif [[ "$PKG" == "apt" ]]; then
        for log in /usr/share/doc/php*-fpm/changelog.Debian.gz /usr/share/doc/php*-common/changelog.Debian.gz; do
            [[ -f "$log" ]] || continue
            grep -q 'CVE-2026-109618' <<< "$(zcat "$log" 2>/dev/null || true)" && return 0
        done
    fi
    return 1
}
php_says() {
    local v
    v="$(php_fpm_version)"; v="${v:-?}"
    if php_fixed; then
        ok "PHP $v has the php2shell fix (CVE-2026-109618, CVE-2026-109619)"
    else
        warn "PHP $v does NOT have the php2shell fix (CVE-2026-109618, CVE-2026-109619)"
    fi
}
php_guard() {           # the second layer, for every PHP on the machine
    local dir
    for dir in /etc/php.d /etc/php/*/fpm/conf.d /etc/php/*/cli/conf.d; do
        [[ -d "$dir" ]] || continue
        if [[ -f "$dir/99-php2shell.ini" ]] && grep -q 'upload_progress.enabled *= *0' "$dir/99-php2shell.ini"; then
            continue
        fi
        install -m 0644 "$HERE/deploy/99-php2shell.ini" "$dir/99-php2shell.ini"
        PHP_RELOAD=yes
        ok "$dir/99-php2shell.ini - session upload progress off, sessions strict"
    done
}
remi_php() {
    [[ "$PKG" == "dnf" ]] || { warn "Remi's repository is for the RHEL family only"; return 1; }
    say "Remi's repository (rpms.remirepo.net), PHP 8.4"
    if ! rpm -q remi-release >/dev/null 2>&1; then
        dnf install -y "https://rpms.remirepo.net/enterprise/remi-release-${OS_MAJOR:-9}.rpm" \
            || { warn "remi-release could not be installed (is rpms.remirepo.net reachable?)"; return 1; }
    fi
    dnf config-manager --set-enabled remi-modular >/dev/null 2>&1 || true
    dnf module reset -y php || true
    dnf module enable -y php:remi-8.4 || { warn "php:remi-8.4 could not be enabled"; return 1; }
    dnf distro-sync -y 'php*'
    dnf install -y php-fpm php-cli php-common
}
php_enabled_stream() {
    awk '/^php /{print $2; exit}' <<< "$(dnf -q module list --enabled php 2>/dev/null || true)"
}
php_on_target() {      # 0: php-fpm is on PHP_STREAM (or newer) and fixed
    local v
    v="$(php_fpm_version)"
    [[ -n "$v" ]] || return 1
    ver_ge "$v" "$PHP_STREAM" || return 1
    php_fixed
}
php_fpm_ok() {         # php-fpm takes its configuration and runs
    local b unit ok=0
    b="$(php_fpm_bin)"
    [[ -n "$b" ]] || return 1
    "$b" -t >/dev/null 2>&1 || return 1
    for unit in $(php_fpm_units); do
        systemctl is-enabled --quiet "$unit" 2>/dev/null || systemctl is-active --quiet "$unit" 2>/dev/null || continue
        systemctl restart "$unit" >/dev/null 2>&1 || return 1
        sleep 2
        systemctl is-active --quiet "$unit" || return 1
        ok=1
    done
    [[ $ok == 1 ]] || ! systemctl list-unit-files 'php*-fpm.service' --no-legend 2>/dev/null | grep -q .
}
php_switch_stream() {  # PHP moved onto php:$PHP_STREAM - put back as it was on any doubt
    local prev saved
    prev="$(php_enabled_stream)"
    saved="$STATE/backup/php-$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$saved"
    cp -a /etc/php.ini /etc/php.d /etc/php-fpm.conf /etc/php-fpm.d "$saved/" 2>/dev/null || true
    rpm -qa 'php*' --qf '%{NAME}\n' 2>/dev/null | sort > "$saved/packages.txt"
    say "PHP $(php_fpm_version) (stream ${prev:-default}) goes onto php:$PHP_STREAM - its settings are"
    say "kept (and copied to $saved)"
    if dnf -y module reset php >/dev/null 2>&1 && dnf -y module enable "php:$PHP_STREAM" \
        && dnf -y --refresh distro-sync 'php*' && php_fpm_ok; then
        ok "PHP is now $(php_fpm_version) (php:$PHP_STREAM)"
        return 0
    fi
    warn "PHP did not come up on php:$PHP_STREAM - it is put back on ${prev:-the default stream}"
    dnf -y module reset php >/dev/null 2>&1 || true
    [[ -n "$prev" ]] && { dnf -y module enable "php:$prev" >/dev/null 2>&1 || true; }
    dnf -y distro-sync 'php*' >/dev/null 2>&1 || true
    cp -a "$saved"/php.ini /etc/ 2>/dev/null || true
    cp -a "$saved"/php.d "$saved"/php-fpm.d /etc/ 2>/dev/null || true
    cp -a "$saved"/php-fpm.conf /etc/ 2>/dev/null || true
    php_fpm_ok || warn "php-fpm does not run - journalctl -u php-fpm"
    return 1
}
ensure_php() {
    step "PHP, and php2shell"
    local had_php="" unit
    if command -v php-fpm >/dev/null 2>&1 || ls /usr/sbin/php-fpm* >/dev/null 2>&1; then had_php=yes; fi
    if [[ -z "$PHP_UPDATE" ]]; then
        say "--no-php-update: PHP is left as it is"
        php_says; php_guard; return 0
    fi
    if [[ -n "$had_php" && -z "$USE_REMI" ]] && php_fixed && { [[ "$PKG" != "dnf" ]] || php_on_target; }; then
        say "PHP $(php_fpm_version) is fixed and on $PHP_STREAM or newer: left as it is"
        php_says; php_guard; return 0
    fi
    if [[ "$PKG" == "dnf" ]]; then
        if [[ -n "$USE_REMI" ]]; then
            remi_php || true
        elif [[ -n "$had_php" ]]; then
            if ver_ge "$(php_fpm_version)" "$PHP_STREAM"; then
                # On the stream already (or a newer one): its newest build.
                say "PHP $(php_fpm_version) is updated within its stream"
                dnf upgrade -y --refresh 'php*' || warn "dnf upgrade 'php*' did not go through"
            else
                # Older than the stream (8.0, 8.1, 8.2): onto php:8.3, 8.3.36 at least.
                php_switch_stream || true
            fi
        else
            local now
            now="$(php_enabled_stream)"
            if [[ -z "$now" ]] || ! ver_ge "$now" "$PHP_STREAM"; then
                say "PHP comes from the stream php:$PHP_STREAM"
                dnf module reset -y php >/dev/null 2>&1 || true
                dnf module enable -y "php:$PHP_STREAM" || true
            else
                say "the PHP stream php:$now is enabled already: it is kept"
            fi
            dnf install -y php-fpm php-cli php-common || warn "php-fpm could not be installed"
        fi
    elif [[ "$PKG" == "apt" ]]; then
        apt-get update || true
        if [[ -n "$had_php" ]]; then
            local have
            have="$(dpkg-query -W -f='${Package} ${Status}\n' 'php*' 2>/dev/null | awk '/ installed$/{print $1}' | tr '\n' ' ' || true)"
            [[ -n "$have" ]] && { apt-get install -y --only-upgrade $have || true; }
        else
            apt-get install -y php-fpm php-cli || true
        fi
    else
        warn "this distribution is not one this knows: install php-fpm yourself, fixed against php2shell"
    fi
    if ! php_fixed && [[ "$PKG" == "dnf" && -z "$USE_REMI" ]]; then
        warn "the PHP AppStream has here is not fixed yet: $(php_fpm_version)"
        # Never by itself in an upgrade: it moves every PHP site to 8.4.
        if [[ "$MODE" == upgrade || "$YES" == 1 ]]; then
            say "Remi's PHP 8.4 is not taken by itself: ./install.sh --upgrade --remi"
        elif [ -t 0 ] && ask "Take PHP 8.4 from Remi's repository instead (fixed in 8.4.27)?"; then
            remi_php || true
        fi
    fi
    php_says
    if [[ "$PKG" == "dnf" ]] && ! ver_ge "$(php_fpm_version)" "$PHP_MIN"; then
        warn "PHP is $(php_fpm_version), not $PHP_MIN or newer yet"
    fi
    if ! php_fixed; then
        warn "Until it is fixed: dnf upgrade --refresh 'php*' as soon as the fixed build is out,"
        warn "and ./install.sh --upgrade. plexmon's pages are guarded meanwhile: upload progress"
        warn "is off everywhere and nginx refuses every multipart body to /smart/."
    fi
    php_guard
    # The new build only counts once php-fpm runs it.
    for unit in $(php_fpm_units); do
        systemctl is-active --quiet "$unit" 2>/dev/null || continue
        systemctl restart "$unit" || warn "$unit would not restart"
    done
    PHP_RELOAD=""
}
ensure_php

FPM_USER=""
for f in /etc/php-fpm.d/www.conf /etc/php/*/fpm/pool.d/www.conf; do
    [ -f "$f" ] && FPM_USER=$(sed -n 's/^\s*user\s*=\s*\(\S*\).*/\1/p' "$f" | head -1) && break
done
[ -n "$FPM_USER" ] || { id apache >/dev/null 2>&1 && FPM_USER=apache; }
[ -n "$FPM_USER" ] || { id nginx >/dev/null 2>&1 && FPM_USER=nginx; }
[ -n "$FPM_USER" ] || FPM_USER=root
WEB_GROUP="$(id -gn "$FPM_USER" 2>/dev/null || echo root)"
if command -v php-fpm >/dev/null || ls /usr/sbin/php-fpm* >/dev/null 2>&1; then
    ok "php-fpm runs the pages as $FPM_USER (group $WEB_GROUP)"
else
    warn "php-fpm is not installed - the pages need it (dnf install -y php-fpm)"
fi
if ! "$PY" -c 'import colorama' 2>/dev/null; then
    "$PY" -m pip install -q colorama >/dev/null 2>&1 || dnf install -y -q python3-colorama >/dev/null 2>&1 || true
fi

# ---------------------------------------------------------------------------
step "The old setup taken over"
mkdir -p "$STATE/backup" && chmod 700 "$STATE"
stamp=$(date +%Y%m%d-%H%M%S)
# The timers and helpers of the PHP collector before the daemon (the old
# INSTALL.md's step 1), where any are still there.
for u in plex-status.timer plex-status-sessions.timer plex-status-wake.path plex-status-wake.service; do
    if [ -e "$UNITS/$u" ]; then
        systemctl disable --now "$u" >/dev/null 2>&1
        mv -f "$UNITS/$u" "$STATE/backup/$u.$stamp"
        say "the old $u is gone (kept in $STATE/backup)"
    fi
done
rm -f /etc/sudoers.d/plex-status /usr/local/sbin/plex-status-collect.php /usr/local/sbin/plex-lib.php
if [ -n "$OLD_UNIT" ]; then
    systemctl stop plex-status.service >/dev/null 2>&1
    systemctl disable plex-status.service >/dev/null 2>&1
    cp -a "$OLD_UNIT" "$STATE/backup/plex-status.service.$stamp"
    rm -f "$OLD_UNIT"
    ok "plex-status.service stopped and replaced by plexmon.service (that name still works)"
fi
if [ -d "$UNITS/plex-status.service.d" ]; then
    mkdir -p "$UNITS/plexmon.service.d"
    for f in "$UNITS/plex-status.service.d"/*.conf; do
        [ -f "$f" ] || continue
        cp -a "$f" "$UNITS/plexmon.service.d/$(basename "$f")"
        say "your limits carried over: $(basename "$f") → plexmon.service.d/"
    done
    mv "$UNITS/plex-status.service.d" "$STATE/backup/plex-status.service.d.$stamp"
fi
[ -d "$OLD_STATE" ] && ok "the history and the SMART cache stay in $OLD_STATE"
[ -f /etc/plex-status/config.json ] && ok "the dashboard's settings stay in /etc/plex-status/config.json"

# ---------------------------------------------------------------------------
step "The program"
systemctl stop plexmon.service >/dev/null 2>&1
mkdir -p "$LIB/release-keys" "$LIB/tools"
install -m 755 "$HERE/plexmon.py" "$LIB/plexmon.py"
install -m 644 "$HERE/plexmon_admin.py" "$LIB/plexmon_admin.py"
install -m 644 "$HERE/plexmon_plex.py" "$LIB/plexmon_plex.py"
install -m 644 "$HERE/plexmon_host.py" "$LIB/plexmon_host.py"
install -m 755 "$HERE/deploy/plexmon_upgrade.py" "$LIB/plexmon_upgrade.py"
install -m 644 "$HERE/CHANGELOG.md" "$LIB/CHANGELOG.md"
for f in "$HERE"/tools/*; do install -m 755 "$f" "$LIB/tools/$(basename "$f")"; done
for k in "$HERE"/deploy/release-keys/*.pub; do install -m 644 "$k" "$LIB/release-keys/$(basename "$k")"; done
chown -R root:root "$LIB"
chmod 755 "$LIB" "$LIB/release-keys"
# The oldest version this machine may go back to: the highest of every
# version put in here - root's alone (plexmon_upgrade.py reads it).
was_floor="$(cat "$LIB/downgrade-floor" 2>/dev/null || echo 0.0.0)"
printf '%s\n%s\n' "$was_floor" "$FLOOR" | sort -V | tail -1 > "$LIB/downgrade-floor"
chmod 644 "$LIB/downgrade-floor"
rm -rf "$LIB/__pycache__"
cat > "$BIN" <<EOF
#!/bin/bash
# plexmon - the dashboard's daemon and Settings, on the command line (plexmon --help).
exec $PY $LIB/plexmon.py "\$@"
EOF
chmod 755 "$BIN"
ok "$LIB, $BIN"

step "The pages"
mkdir -p "$WEB/settings" "$WEB/assets" "$WEB/lang"
for f in index.php plexmon-api.php plexmon-page.php plexmon-admin-api.php; do
    install -m 644 "$HERE/web/$f" "$WEB/$f"
done
install -m 644 "$HERE/web/settings/index.php" "$WEB/settings/index.php"
for f in "$HERE"/web/assets/*; do install -m 644 "$f" "$WEB/assets/$(basename "$f")"; done
for f in "$HERE"/web/lang/*.json; do install -m 644 "$f" "$WEB/lang/$(basename "$f")"; done
chown root:root "$WEB/settings" "$WEB/assets" "$WEB/lang"
chgrp "$WEB_GROUP" "$WEB/settings" 2>/dev/null
ok "$WEB (the dashboard) and $WEB/settings/ (Settings)"

step "Where it keeps things"
mkdir -p "$ETC" "$LOGS" "$STATE/upgrade" "$ACME_ROOT/.well-known/acme-challenge" /etc/plex-status "$OLD_STATE"
chmod 750 "$ETC" "$LOGS" "$STATE/upgrade"
chmod 755 "$ACME_ROOT" "$ACME_ROOT/.well-known" "$ACME_ROOT/.well-known/acme-challenge"
[ -f "$ETC/config.json" ] || echo '{}' > "$ETC/config.json"
chmod 640 "$ETC/config.json"
install -m 644 "$HERE/deploy/plexmon.logrotate" /etc/logrotate.d/plexmon
[ -f "$ETC/console-login" ] || echo off > "$ETC/console-login"
install -m 644 "$HERE/deploy/plexmon-console-login.sh" /etc/profile.d/zz-plexmon-console.sh
ok "$STATE (SQLite), $ETC, $LOGS"

step "The services"
for u in plexmon.service plexmon-upgrade.path plexmon-upgrade.service; do
    sed "s#@PYTHON@#$PY#g" "$HERE/deploy/$u" > "$UNITS/$u"
    chmod 644 "$UNITS/$u"
done
mkdir -p "$UNITS/plexmon.service.d"
cat > "$UNITS/plexmon.service.d/00-web-group.conf" <<EOF
# Written by install.sh: the group of the web pages (php-fpm's $FPM_USER), which
# may read the API token in /run/plexmon.
[Service]
Environment=PLEXMON_WEB_GROUP=$WEB_GROUP
EOF
systemctl daemon-reload
systemctl enable plexmon.service plexmon-upgrade.path >/dev/null 2>&1
systemctl start plexmon-upgrade.path
ok "plexmon.service, plexmon-upgrade.path"

# Only errors on the machine's console (2.5.4, as otp 1.0.210). Every
# `systemctl daemon-reload` - each RPM's scriptlets in a system update, an
# upgrade - makes systemd's rc-local generator say "/etc/rc.d/rc.local is not
# marked executable, skipping" into the kernel's log; with a console log level
# above 4 the kernel prints it over the console, plexmon --console included.
# The level goes to RHEL's own 4 (errors and worse); the journal keeps every
# message (journalctl -k). An administrator's own kernel.printk is left alone.
console_quiet() {
    local file=/etc/sysctl.d/80-plexmon-console.conf own
    own=$(grep -ls '^[[:space:]]*kernel\.printk' /etc/sysctl.d/*.conf /etc/sysctl.conf 2>/dev/null \
          | grep -v "^$file\$" | tr '\n' ' ' || true)
    own=${own% }
    if [ -n "$own" ]; then
        say "kernel.printk is set by hand ($own): left as it is"
        return 0
    fi
    printf '%s\n' '# Written by plexmon (install.sh): only errors on the console;' \
        '# every message is still in journalctl -k. Taken away by install.sh --uninstall.' \
        'kernel.printk = 4 4 1 7' > "$file"
    chmod 0644 "$file"
    sysctl -q -p "$file" >/dev/null 2>&1 || true
    ok "the console: only errors (kernel.printk 4 4 1 7, $file)"
}
console_quiet

step "nginx: the Plex vhost"
if [ -f "$NGINX_SITE" ]; then
    if grep -q "include /etc/nginx/plexmon/tls.conf" "$NGINX_SITE"; then
        ok "$NGINX_SITE is plexmon's already"
        # php2shell: plexmon's PHP pages refuse a form or multipart body.
        PLEXMON_WEB_GROUP="$WEB_GROUP" "$PY" "$LIB/plexmon_admin.py" --nginx-adopt | sed -n '2,$p' | sed 's/^/    /'
    else
        say "its ssl_* lines go to /etc/nginx/plexmon/tls.conf as they are, and every server"
        say "answers /.well-known/acme-challenge/ for the CA - nothing else changes; a copy"
        say "of it as it was goes to $STATE/backup/"
        if PLEXMON_WEB_GROUP="$WEB_GROUP" "$PY" "$LIB/plexmon_admin.py" --nginx-adopt; then
            ok "adopted"
        else
            warn "left as it was - the certificate can be put in from Settings, but not its TLS settings"
        fi
    fi
else
    warn "$NGINX_SITE is not there: put deploy/nginx-plex.conf.example there (and adjust it), then ./install.sh --upgrade"
fi

# ---------------------------------------------------------------------------
# SELinux (2.9.0, as otp does it). Nothing changes unless somebody asks: a machine with SELinux
# disabled stays so - only the tools are put in (Settings -> SELinux needs them to make it
# ready) and plexmon's module is laid beside the program. Where SELinux is on: the module put
# into the policy when it changed, the labels of plexmon's files, and the boolean that lets
# nginx pass Plex on and the pages ask the daemon.
selinux_tools() {
    [[ "$PKG" == "dnf" ]] || return 0
    [[ -d /etc/selinux || -x /usr/sbin/getenforce ]] || return 0
    local want=() p
    for p in policycoreutils libselinux-utils policycoreutils-python-utils audit selinux-policy-targeted setools-console; do
        rpm -q "$p" >/dev/null 2>&1 || want+=("$p")
    done
    if (( ${#want[@]} )); then
        if dnf install -y -q "${want[@]}" >/dev/null 2>&1; then
            ok "SELinux: put in ${want[*]}"
        else
            warn "SELinux: ${want[*]} could not be put in (no repository reached?) - dnf install -y ${want[*]}"
        fi
    fi
    if command -v getenforce >/dev/null 2>&1 && [[ "$(getenforce 2>/dev/null)" != "Disabled" ]] &&
            command -v auditd >/dev/null 2>&1 && ! systemctl is-active --quiet auditd 2>/dev/null; then
        # auditd refuses to be started by systemctl on some releases: service(8) then.
        if systemctl enable --now auditd >/dev/null 2>&1 || service auditd start >/dev/null 2>&1; then
            ok "SELinux: auditd started - what SELinux refuses is written down"
        else
            warn "SELinux: auditd could not be started - systemctl enable --now auditd"
        fi
    fi
    return 0
}
selinux_module() {
    selinux_tools
    install -m 0644 "$HERE/deploy/plexmon_server.cil" "$LIB/plexmon_server.cil"
    command -v getenforce >/dev/null 2>&1 || return 0
    command -v semodule >/dev/null 2>&1 || return 0
    [[ "$(getenforce 2>/dev/null)" == "Disabled" ]] && { say "SELinux is disabled: left so (Settings -> SELinux)"; return 0; }
    local had=""
    # Compared with the one last put into the policy, not with the copy beside the program:
    # a semodule that failed once would leave the copy new and the policy old for good.
    cmp -s "$LIB/plexmon_server.cil" "$LIB/plexmon_server.cil.in-policy" 2>/dev/null && had=1
    if [[ -z "$had" ]] || ! semodule -l 2>/dev/null | awk '$1=="plexmon_server"{f=1} END{exit !f}'; then
        if semodule -i "$LIB/plexmon_server.cil" 2>/dev/null; then
            install -m 0644 "$LIB/plexmon_server.cil" "$LIB/plexmon_server.cil.in-policy"
            ok "SELinux: plexmon's module (plexmon_server) is in the policy"
        else
            warn "SELinux: plexmon's module could not be put in: semodule -i $LIB/plexmon_server.cil"
        fi
    fi
    if command -v getsebool >/dev/null 2>&1 && ! getsebool httpd_can_network_connect 2>/dev/null | grep -q -- '--> on'; then
        setsebool -P httpd_can_network_connect 1 >/dev/null 2>&1 &&
            ok "SELinux: httpd_can_network_connect on - nginx passes Plex on, the pages ask the daemon" ||
            warn "SELinux: setsebool -P httpd_can_network_connect 1 failed"
    fi
    if command -v restorecon >/dev/null 2>&1; then
        restorecon -R "$WEB" "$ACME_ROOT" >/dev/null 2>&1 || true
    fi
    if command -v matchpathcon >/dev/null 2>&1; then
        local want
        want="$(matchpathcon /run/plexmon 2>/dev/null || true)"
        case "$want" in
            *httpd_var_run_t*|*httpd_runtime_t*) ;;
            *) warn "SELinux: the policy does not label /run/plexmon for the pages (${want:-nothing}) - plexmon --selinux-check";;
        esac
    fi
}
step "SELinux"
selinux_module

step "Starting"
systemctl restart plexmon.service
for i in $(seq 1 30); do
    [ -s /run/plexmon/api-port ] && break
    sleep 1
done
if command -v getenforce >/dev/null 2>&1 && [[ "$(getenforce 2>/dev/null)" != "Disabled" ]] &&
        command -v restorecon >/dev/null 2>&1; then
    restorecon -R /run/plexmon /run/plex-status >/dev/null 2>&1 || true
fi
if systemctl is-active --quiet plexmon.service; then
    ok "plexmon.service is running"
else
    warn "plexmon.service does not run: journalctl -u plexmon -n 50"
fi
for svc in php-fpm nginx; do
    systemctl is-active --quiet "$svc" && systemctl reload "$svc" >/dev/null 2>&1
done

# ---------------------------------------------------------------------------
if ! "$PY" "$LIB/plexmon_admin.py" --users --json 2>/dev/null | grep -q '"role": "fulladmin"'; then
    step "The first account of Settings"
    first="$STATE/first-login.txt"
    pw="$("$PY" -c 'import secrets; print(secrets.token_urlsafe(12))')"
    if echo "$pw" | "$PY" "$LIB/plexmon_admin.py" --add-user admin --role fulladmin >/dev/null; then
        "$PY" - "$STATE/plexmon.db" <<'EOF' >/dev/null 2>&1
import sqlite3, sys
c = sqlite3.connect(sys.argv[1]); c.execute("UPDATE accounts SET must_change = 1 WHERE name = 'admin'"); c.commit()
EOF
        printf 'Settings of plexmon - the first sign-in\nname: admin\npassword: %s\n(chosen anew at the first sign-in; this file goes then)\n' "$pw" > "$first"
        chmod 600 "$first"
        ok "name ${B}admin${N}, password ${B}$pw${N} - you choose your own at the first sign-in"
        say "(also in $first, until then)"
    else
        warn "no account could be made: plexmon --add-user NAME --role fulladmin"
    fi
fi

step "Done"
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
say "plexmon $VERSION"
say "the dashboard:  https://$(hostname -f 2>/dev/null || hostname)/smart/   (or https://$IP/smart/)"
say "Settings:       https://$(hostname -f 2>/dev/null || hostname)/smart/settings/"
say "on the server:  plexmon · plexmon --console · plexmon --help"
exit 0
